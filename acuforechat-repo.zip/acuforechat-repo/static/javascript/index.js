document.getElementById("toggle-chat").addEventListener("click", function () {
  const chatbox = document.getElementById("chatbox");
  chatbox.style.display =
    chatbox.style.display === "none" || chatbox.style.display === ""
      ? "block"
      : "none";
});

document.getElementById("close-chat").addEventListener("click", function () {
  const popup = document.querySelector(".clear-popup");
  popup.style.display = "block";
});

document.querySelector(".cancel-btn").addEventListener("click", function () {
  const popup = document.querySelector(".clear-popup");
  popup.style.display = "none";
});

document.querySelector(".clear-btn").addEventListener("click", function () {
  clearChatMessages();
  const popup = document.querySelector(".clear-popup");
  popup.style.display = "none";
});

function clearChatMessages() {
  const messages = document.getElementById("messages");
  if (messages) {
    let child = messages.firstChild;
    while (child) {
      if (
        !child.classList ||
        (!child.classList.contains("") &&
          !child.classList.contains("menu-container"))
      ) {
        const nextChild = child.nextSibling;
        messages.removeChild(child);
        child = nextChild;
      } else {
        child = child.nextSibling;
      }
    }
  }
}

document.getElementById("minimize-chat").addEventListener("click", function () {
  document.getElementById("chatbox").style.display = "none";
});

document.getElementById("send-button").addEventListener("click", function () {
  sendMessage();
});

document
  .getElementById("message-input")
  .addEventListener("keypress", function (event) {
    if (event.key === "Enter") {
      sendMessage();
    }
  });

function addMessage({ content, type, messageType = "responses" }) {
  const messageContainer = document.getElementById("messages");
  const messageDiv = document.createElement("div");

  if (messageType === "input") {
    messageDiv.className = `message ${type}`;
  } else if (messageType === "dropdown") {
    messageDiv.className = `message-dropdown ${type}`;
  } else {
    messageDiv.className = `message-daq ${type}`;
  }

  if (content.startsWith("<") && content.endsWith(">")) {
    messageDiv.innerHTML = content;
  } else {
    messageDiv.textContent = content;
  }

  messageContainer.appendChild(messageDiv);
  messageContainer.scrollTop = messageContainer.scrollHeight;
}

function addMessageLinks(links, type) {
  if (
    links &&
    (typeof links === "string" ||
      typeof links === "null" ||
      (Array.isArray(links) && links.length > 0))
  ) {
    const messageContainer = document.getElementById("messages");

    const messageDiv = document.createElement("div");
    messageDiv.className = `message-daq ${type}`;

    let linkContent = `<strong>Read more about the product:</strong><ul>`;
    if (typeof links === "string") {
      linkContent += `<li>${links}<img src="./static/images/external.png" alt="Baumalight Mascot" class="link-icon-sm"></li>`;
    } else if (Array.isArray(links)) {
      links.forEach((link) => {
        linkContent += `<li><a>${link}</a><img src="./static/images/external.png" alt="Baumalight Mascot" class="link-icon-sm"></li>`;
      });
    }
    linkContent += `</ul>`;
    messageDiv.innerHTML = linkContent;

    messageContainer.appendChild(messageDiv);
    messageContainer.scrollTop = messageContainer.scrollHeight;
  }
}

function addMessageDescription(message, type) {
  if (message && message.trim()) {
    const messageContainer = document.getElementById("messages");
    const messageDiv = document.createElement("div");
    messageDiv.className = `message-daq ${type}`;

    // Limit message to 100 words
    const words = message.trim().split(/\s+/);
    const limitedMessage =
      words.length > 100 ? words.slice(0, 100).join(" ") + "..." : message;

    messageDiv.innerHTML = `<p>${limitedMessage}</p>`;
    messageContainer.appendChild(messageDiv);
    messageContainer.scrollTop = messageContainer.scrollHeight;
  }
}

function addMessageQuestion(questions, type) {
  if (questions && Array.isArray(questions) && questions.length > 0) {
    const messageContainer = document.getElementById("messages");

    const messageDiv = document.createElement("div");
    messageDiv.className = `message-daq ${type}`;

    questions.forEach((question) => {
      const button = document.createElement("button");
      button.className = "clickable-question statement-container1";
      button.setAttribute("data-question", question.trim());
      button.textContent = question.trim();
      messageDiv.appendChild(button);
    });

    messageContainer.appendChild(messageDiv);
    messageContainer.scrollTop = messageContainer.scrollHeight;
  }
}

function addMessageDefault() {
  const messageContainer = document.getElementById("messages");

  const messageDiv = document.createElement("div");
  messageDiv.className = "message-daq";

  messageDiv.innerHTML = `
        <p>Sorry! couldn't find what you were searching for. here are some options to try from</p>
        <strong>Related about the product:</strong>
        <button class="clickable-question statement-container1" data-question="would you like to know more about our tractor models?">would you like to know more about our tractor models?</button>
        <button class="clickable-question statement-container1" data-question="what products are eligible for the factory discount program?">what products are eligible for the factory discount program?</button>
        <button class="clickable-question statement-container1" data-question="Would you prefer leasing or purchasing with financing options?">Would you prefer leasing or purchasing with financing options?</button>
    `;

  messageContainer.appendChild(messageDiv);
  messageContainer.scrollTop = messageContainer.scrollHeight;
}

function sendMessage(event) {
  const input = document.getElementById("message-input");
  if (event && event.target !== input) return;

  const messageText = input.value.trim();
  const messageContainer = document.getElementById("messages");

  if (messageText) {
    addMessage(messageText, "sender", "input");
    input.value = "";
    showLoader();

    const processedMessage = getChatbotResponse(messageText);

    fetch("/ask", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        prompt: messageText,
        max_results: 3,
        include_sources: true,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        hideLoader();

        if (data.response) {
          try {
            const response = JSON.parse(data.response);
            if (response.Description)
              addMessageDescription(response.Description, "receiver");
            if (response.Links) addMessageLinks(response.Links, "receiver");
            if (response.Questions)
              addMessageQuestion(response.Questions, "receiver");
          } catch (error) {
            console.error("Error parsing response:", error);
            addBotResponse(data.response, messageContainer); // Changed to addBotResponse
          }
        } else {
          addMessageDefault("receiver");
        }

        // Remove the timestamp addition here
        // Create a container for timestamp and feedback icons
        const timestampContainer = document.createElement("div");
        timestampContainer.className = "timestamp-feedback-container";

        // Add timestamp
        const timestampElement = document.createElement("div");
        timestampElement.className = "message-timestamp timestamp-left";
        timestampElement.textContent = getCurrentTime();

        // Add feedback icons
        const feedbackIcons = document.createElement("div");
        feedbackIcons.className = "feedback-icons";
        feedbackIcons.innerHTML = `
                     <i class="fa-regular fa-thumbs-up thumb-icon" id="thumbs-up"></i>
                     <i class="fa-regular fa-thumbs-down thumb-icon" id="thumbs-down"></i>
                 `;

        // Append timestamp and feedback icons to their container
        timestampContainer.appendChild(timestampElement);
        timestampContainer.appendChild(feedbackIcons);

        // Append the container to the message container
        messageContainer.appendChild(timestampContainer);

        setTimeout(() => {
          messageContainer.scrollTop = messageContainer.scrollHeight;
        }, 100);
      })
      .catch((error) => {
        console.error("Error:", error);
        addMessageDefault("receiver");
        hideLoader();
      });
  }
}

function addBotResponse(content, messageContainer) {
  const botResponse = document.createElement("div");
  botResponse.className = "message-container bot-message";

  const botMessage = document.createElement("div");
  botMessage.className = "message-daq receiver";
  botMessage.innerHTML = content;

  botResponse.appendChild(botMessage);

  messageContainer.appendChild(botResponse);
}

function isJSON(str) {
  try {
    JSON.parse(str);
    return true;
  } catch (error) {
    return false;
  }
}

function printInputMessage(message) {
  console.log("Input Message:", message);
}

function sendInputMessage() {
  const input = document.getElementById("message-input");
  const messageText = input.value.trim();

  if (messageText) {
    const processedMessage = messageText;
    printInputMessage(processedMessage);
    input.value = "";

    showLoader();

    fetch("/ask", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        prompt: messageText,
        max_results: 3,
        include_sources: true,
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        hideLoader();
        if (data.response) {
          try {
            const response = JSON.parse(data.response);
            if (response.Description)
              addMessageDescription(response.Description, "receiver");
            if (response.Links) addMessageLinks(response.Links, "receiver");
            if (response.Questions)
              addMessageQuestion(response.Questions, "receiver");
          } catch (error) {
            console.error("Error parsing response:", error);
            addMessage(data.response, "receiver", "response");
          }
        } else {
          addMessageDefault("receiver");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        addMessageDefault("receiver");
        hideLoader();
      });
  }
}

document
  .getElementById("send-button")
  .addEventListener("click", sendInputMessage);

document.addEventListener("DOMContentLoaded", function () {
  const messageInput = document.getElementById("message-input");
  const sendButton = document.getElementById("send-button");

  messageInput.addEventListener("input", function () {});

  sendButton.addEventListener("click", function () {
    if (messageInput.value) {
    }
  });
});

function getChatbotResponse(query) {
  let response = "";
  return response;
}

document.addEventListener("DOMContentLoaded", function () {
  const messageInput = document.getElementById("message-input");
  const sendButton = document.getElementById("send-button");
  const chatContainer = document.querySelector(".chatbox-messages");

  function sendMessage(text) {
    messageInput.value = text;

    const inputEvent = new Event("input", { bubbles: true });
    messageInput.dispatchEvent(inputEvent);

    const clickEvent = new MouseEvent("click", {
      bubbles: true,
      cancelable: true,
      view: window,
    });
    sendButton.dispatchEvent(clickEvent);
  }

  function activateQuestionListeners() {
    chatContainer.addEventListener("click", function (e) {
      const clickedQuestion = e.target.closest(".clickable-question");
      if (clickedQuestion) {
        const questionText =
          clickedQuestion.dataset.question || clickedQuestion.textContent;
        sendMessage(questionText.trim());
      }
    });
  }

  activateQuestionListeners();
});

document.addEventListener("DOMContentLoaded", function () {
  const messagesContainer = document.getElementById("messages");

  chatbox.addEventListener("click", function (event) {
    if (event.target.classList.contains("thumb-icon")) {
      const iconType = event.target.id;
      const feedbackContainer = event.target.closest(".feedback-icons");

      //   if (feedbackContainer) {
      //     // Check if feedback message already exists
      //     const existingFeedback = document.querySelector(".message-daqr");
      //     if (existingFeedback) {
      //       // If feedback already exists, don't add another one
      //       return;
      //     }

      //     const feedbackMessage = document.createElement("div");
      //     feedbackMessage.className = "message-daqr";
      //     feedbackMessage.textContent =
      //       iconType === "thumbs-up"
      //         ? "Thank you for your feedback!"
      //         : "Sorry to hear that! We value your feedback.";

      //     const messageContainer = document.getElementById("messages");
      //     messageContainer.appendChild(feedbackMessage);

      //     // Remove all feedback icons after clicking
      //     removeFeedbackIcons();

      //     messageContainer.scrollTop = messageContainer.scrollHeight;
      //   }
    }
  });
});

function showLoader() {
  const loader = document.getElementById("message-loader");
  loader.style.display = "block";
}

function hideLoader() {
  const loader = document.getElementById("message-loader");
  loader.style.display = "none";
}

document.addEventListener("DOMContentLoaded", function () {
  const initialMessageContainers = document.querySelectorAll(
    ".message-initial-input"
  );
  const initialMessages = document.querySelectorAll(".message-initial");
  const chatbox = document.getElementById("chatbox");

  initialMessages.forEach((message) => {
    message.addEventListener("click", function () {
      const messageText = this.textContent.trim();
      const input = document.getElementById("message-input");
      input.value = messageText;
      input.dispatchEvent(new Event("input", { bubbles: true }));
      document.getElementById("send-button").click();
      initialMessageContainers.forEach((container) => {
        container.style.display = "none";
      });
    });
  });
});

document.addEventListener("DOMContentLoaded", function () {
  document
    .getElementById("chatbox")
    .addEventListener("click", function (event) {
      if (event.target.classList.contains("thumb-icon")) {
        const iconType = event.target.id;
        if (iconType === "thumbs-up") {
        } else if (iconType === "thumbs-down") {
        }
        event.target.style.opacity = 0.5;
      }
    });
});

function toggleDropdown(dropdownId) {
  const dropdown = document.getElementById(dropdownId);
  const chevron = dropdown.previousElementSibling.querySelector(".chevron img");

  if (dropdown.style.display === "grid" || dropdown.style.display === "") {
    dropdown.style.display = "none";
    chevron.style.transform = "rotate(180deg)";
  } else {
    dropdown.style.display = "grid";
    chevron.style.transform = "rotate(0deg)";
  }
}

document.querySelectorAll(".menu-item").forEach((button) => {
  button.addEventListener("click", () => {
    button.classList.toggle("active");
    const dropdown = button.nextElementSibling;
    if (dropdown.style.maxHeight) {
      dropdown.style.maxHeight = null;
    } else {
      dropdown.style.maxHeight = dropdown.scrollHeight + "px";
    }
  });
});

function addMessage(message, type, messageType = "responses") {
  const messageContainer = document.getElementById("messages");
  const messageDiv = document.createElement("div");

  if (messageType === "input") {
    messageDiv.className = `message ${type}`;
  } else if (messageType === "dropdown") {
    messageDiv.className = `message-dropdown ${type}`;
  } else {
    messageDiv.className = `message-daq ${type}`;
  }

  if (content.startsWith("<") && content.endsWith(">")) {
    messageDiv.innerHTML = content;
  } else {
    messageDiv.textContent = content;
  }

  messageContainer.appendChild(messageDiv);
  messageContainer.scrollTop = messageContainer.scrollHeight;
}

function handleMessage(message, isUserMessage) {
  const messageContainer = document.getElementById("messageContainer");

  if (isUserMessage) {
    addUserMessage(message, messageContainer);
  } else {
    addBotResponse(message, messageContainer);
  }

  messageContainer.scrollTop = messageContainer.scrollHeight;
}

function addUserMessage(content, messageContainer) {
  const messageWrapper = document.createElement("div");
  messageWrapper.className = "message-container user-message";

  const messageDiv = document.createElement("div");
  messageDiv.className = "message sender";
  messageDiv.textContent = content;

  const timestampElement = document.createElement("div");
  timestampElement.className = "message-timestamp timestamp-right";
  timestampElement.textContent = getCurrentTime();

  messageWrapper.appendChild(messageDiv);
  messageWrapper.appendChild(timestampElement);

  messageContainer.appendChild(messageWrapper);
}

// Define static responses for dropdown items
const dropdownResponses = {
  "Upcoming New Product Release": {
    description:
      "Barrier Mower : Baumalights Barrier Mower designed for maintaining growth along fenced fields or mowing long, heavy grass along roadway barriers.",
    links: ["https://online-order.baumalight.com/product/barrier-mower-en"],
    questions: ["Skidsteer-BMM230"],
  },
  "Skidsteer-BMM230": {
    description:
      'Designed for Mini Skid Steers, the BMM230 is capable of efficiently cutting through long, heavy grass or small-diameter brush. Equipped with two AR400 blades featuring a 30" path width, the BMM230 Mini Barrier Mower is ideal for maintaining fence lines, guardrails, orchards, and vineyards.',
    links: ["https://online-order.baumalight.com/product/barrier-mower/bmm230"],
  },
  "Discounts and Offers": {
    description:
      "With our Factory Discounts program, there are three possible ways for you to receive different levels discounts on select Baumalight products. Whether this is your first Baumalight product, or you’re an existing customer looking to add a new attachment, we value your help and would be happy to talk with you about one of our factory discount products.",
    links: ["https://online-order.baumalight.com/product/factorydiscounts/en"],
  },
  "Finance Options": {
    description:
      "We have Financing Options for many products with customer friendly Flexible Monthly Payments options with a Competitive Interest Rates. We have variable terms defining from 24 montns to 60 months for Canada, USA and International Currency.",
    links: ["https://baumalight.com/financial_calculator/en/"],
  },
  "Mini Skidsteers": {
    description:
      "Our Mini Skidsteers are compact powerhouses designed for versatile operations in tight spaces. With advanced hydraulic systems and robust construction, these machines offer exceptional maneuverability and performance for various applications.",
    links: ["https://online-order.baumalight.com/product/miniskidsteer-en"],
    questions: ["Skidsteer-Wheeled", "Skidsteer-Tracked"],
  },
  "Skidsteer-Wheeled": {
    description:
      "Baumalight wheeled mini skidsteer is manufactured in Ontario Canada and powered with a Honda engine, the compact wheeled mini tool carriers are designed to easily navigate through tight spaces and are offered with weight kit as an option.",
    links: [
      "https://online-order.baumalight.com/product/miniskidsteer/wheeled-mini-skidsteer",
    ],
    questions: ["Skidsteer-Tracked"],
  },
  "Skidsteer-Tracked": {
    description:
      "Track Loader is designed to easily navigate through tight spaces. Notably, with a width of 36 and 62 inches, it ensures easy access to even the most confined areas and good productivity on the tools powered with a Kubota diesel engine.",
    links: [
      "https://online-order.baumalight.com/product/miniskidsteer/trl536d",
    ],
    questions: ["TRL536D", "TRL620D", "TRL620Y"],
  },
  TRL536D: {
    description:
      "Baumalight TRL536D is the ideal stand-on mini skid steer for a range of big and small jobs available with many tools to do a wide range of tasks. Manufactured in Ontario Canada, the TRL536D stand-on compact Utility Track Loader is designed to easily navigate through tight spaces.",
    links: [
      "https://online-order.baumalight.com/product/miniskidsteer/trl536d",
    ],
    questions: ["TRL620D", "TRL620Y"],
  },
  TRL620D: {
    description:
      "Its remote hydraulic pump system with case drain delivers hydraulic flow that can be set to maximum engine capacity and the standard self-levelling bucket reduces spills and provides extra control when loading and unloading material.",
    links: [
      "https://online-order.baumalight.com/product/miniskidsteer/trl620d",
    ],
    questions: ["TRL536D", "TRL620Y"],
  },
  TRL620Y: {
    description:
      "Baumalight TRL620Y tracked mini skidsteer is manufactured in Ontario Canada and powered with a Yanmar diesel engine, Yanmar rates their engines a bit more conservatively so we show the HP lower but it has a bigger displacement engine and a bit more torque than the Kubota in our other unit.",
    links: [
      "https://online-order.baumalight.com/product/miniskidsteer/trl620y",
    ],
    questions: ["TRL536D", "TRL620D"],
  },
  Dumper: {
    description:
      "Dumpers are built for landscapers to effortlessly move fill and debris in tight spaces. With the ultimate maneuverability, faster travel speeds from higher engine power, our new line of mini dumpers is designed later technology and are heavier duty then many you will find out there. With a variety of variations including tracked, wheeled or trailered models",
    links: ["https://online-order.baumalight.com/product/dumper-en"],
    questions: ["Trailer Dumper", "Tracked Mini Dumper"],
  },
  "Trailer Dumper": {
    description:
      "Trailer Dumper is a cost-effective solution for landscapers to easily move fill and debris through narrow openings and tight spaces.",
    links: ["https://online-order.baumalight.com/product/dumper/dw51qt"],
    questions: ["DW51QT"],
  },
  "Tracked Mini Dumper": {
    description:
      "Tracked Dumper is the ideal solution for landscapers to easily move fill and debris through narrow openings and tight spaces.",
    links: ["https://online-order.baumalight.com/product/dumper/dt515rh"],
    questions: ["DT515RH"],
  },
  DW51QT: {
    description:
      "The DW51QT Mini Trailer Dumper is a cost-effective solution for landscapers to easily move fill and debris through narrow openings and tight spaces. The QT Mini Dumper model uses a mini skidsteer adapter to easily towed by your mini skidsteer.",
    links: ["https://online-order.baumalight.com/product/dumper/dw51qt"],
  },
  DT515RH: {
    description:
      "The DT515RH Mini Tracked Dumper is the ideal solution for landscapers to easily move fill and debris through narrow openings and tight spaces. Powered by a 22 HP Honda engine, this Tracked Dumper has a ground speed of 7.8 km/h and offers a ground clearance of 7.4 inches.",
    links: ["https://online-order.baumalight.com/product/dumper-en"],
  },
  "New ProductRelease": {
    description:
      "Introducing Our New Line of Mini Dumpers. We are excited to announce the release of our latest mini dumpers, specifically designed for landscapers to effortlessly move fill and debris in tight spaces. Featuring ultimate maneuverability and faster travel speeds powered by advanced engine technology, this new line is built to be heavier duty than many options available on the market. Choose from a variety of models, including tracked, wheeled, or trailered versions, to suit your landscaping needs.",
    links: ["https://online-order.baumalight.com/product/dumper-en"],
    questions: ["Trailer Dumper", "Tracked Mini Dumper"],
  },
  "Stump Grinders": {
    description:
      "Baumalight stump grinder line-up includes attachments for many carriers, 3 point hitch stump grinders for tractors, stump grinders for skidsteers, and stump grinder attachments for excavators and backhoes. Self propelled stump grinders, as well as walk behind stumpgrinders, are also offered.",
    links: ["https://online-order.baumalight.com/product/stump-grinder-en"],
    questions: ["Walk Behind Model", "Self Propled"],
  },
  "Walk Behind Model": {
    description:
      "Walk Behind Stump Grinder lets you get to the stumps quickly and easily and is built for stump grinder rental in the rental stump grinding industry.",
    links: ["https://online-order.baumalight.com/product/stump-grinder/wb44"],
    questions: ["WB44"],
  },
  WB44: {
    description:
      "The WB44 Walk Behind Stump Grinder lets you get to the stumps quickly and easily and is built for stump grinder rental in the rental stump grinding industry.",
    links: ["https://online-order.baumalight.com/product/stump-grinder/wb44"],
  },
  "Self Propled": {
    description:
      "Engine Powered stump grinders back in 2011 and have been testing through local rental for many years. In 2014 we branded them as Holt where we have some action pictures and videos.",
    links: [
      "https://online-order.baumalight.com/product/stump-grinder/self-propelled",
    ],
  },
  Generator: {
    description:
      "Baumalight’s TX, KR and QC series of PTO tractor generators give you a variety of choices – from running small tools and appliances to powering large motors on equipment such as silo unloaders and milking systems.",
    links: ["https://online-order.baumalight.com/product/generators-en"],
    questions: ["PTO Generators"],
  },
  "PTO Generators": {
    description:
      "PTO generators, power is as close by as your tractor. A portable, convenient and reliable solution for emergency back-up, in-field repairs or remote power for un-serviced locations",
    links: ["https://online-order.baumalight.com/product/generators-en"],
    questions: ["TX Series", "KR Series", "QC Series"],
  },
  "TX Series": {
    description:
      "Baumalight TX series of PTO generators, power is as close by as your tractor. With one less engine to maintain on your property, the TX series of portable generators gives you the advantage of using your reliable tractor during an emergency situation or simply for additional power when required.",
    links: ["https://online-order.baumalight.com/product/generators/tx-models"],
  },
  "KR Series": {
    description:
      "KR series generators are designed to fit tractors from 45 to 97 horsepower and support power requirements from 30 kilowatts to 65 kilowatts. The KR models generator assembly is made in Canada and the main components are made in Europe.",
    links: ["https://online-order.baumalight.com/product/generators/kr-models"],
  },
  "QC Series": {
    description:
      "QC series tractor powered generator is ideal for your farm or rural property. At 100% load, these QC PTO models offer 12 KW to 100 KW and momentary surge from 25 up to 300 KW. ",
    links: [
      "https://online-order.baumalight.com/product/generators/qc-singlephase",
    ],
    questions: [
      "120/240 Single Phase",
      "120/208 Volt 3-Phase",
      "120/240 Volt 3-Phase",
      "480 Volt 3-Phase",
      "600 Volt 3-Phase",
    ],
  },
  "120/240 Single Phase": {
    description:
      "120/240 Single Phase. Designed for mobile or standby electrical power, the QC series tractor powered generator is ideal for your farm or rural property. At 100% load, these QC PTO models offer 12 KW to 100 KW and momentary surge from 25 up to 300 KW.",
    links: [
      "https://online-order.baumalight.com/product/generators/qc-singlephase",
    ],
    questions: [
      "120/208 Volt 3-Phase",
      "120/240 Volt 3-Phase",
      "480 Volt 3-Phase",
      "600 Volt 3-Phase",
    ],
  },
  "120/208 Volt 3-Phase": {
    description:
      "Baumalight offers QC generators that can be configured for 120/208 voltage and features 30 KW to 105 KW at 100% load and a momentary surge from 85 KW to 315 KW. ",
    links: ["https://online-order.baumalight.com/product/generators/qc-120"],
    questions: [
      "120/240 Single Phase",
      "120/240 Volt 3-Phase",
      "480 Volt 3-Phase",
      "600 Volt 3-Phase",
    ],
  },
  "120/240 Volt 3-Phase": {
    description:
      "QC PTO generator that is configured for 120/240 three phase voltage, at 100% load these generators offer 30 KW to 105 KW and a momentary surge from 85 to 315 KW.",
    links: ["https://online-order.baumalight.com/product/generators/qc-3phase"],
    questions: [
      "120/240 Single Phase",
      "120/208 Volt 3-Phase",
      "480 Volt 3-Phase",
      "600 Volt 3-Phase",
    ],
  },
  "480 Volt 3-Phase": {
    description:
      "QC PTO generator for 480 volt three phase models are ideal for your farm or rural property. At 100% load, these QC PTO models offer 33 KW to 113 KW and momentary surge from 85 KW up to 315 KW.",
    links: [
      "https://online-order.baumalight.com/product/generators/qc-volt480",
    ],
    questions: [
      "120/240 Single Phase",
      "120/208 Volt 3-Phase",
      "120/240 Volt 3-Phase",
      "480 Volt 3-Phase",
      "600 Volt 3-Phase",
    ],
  },
  "600 Volt 3-Phase": {
    description:
      "QC PTO tractor-driven generator models for a Dedicated 377/600 volt three phase output, which is the most frequent voltage distribution feed in Canada and also sometimes referred to as 550 volt. At 100% load, these QC PTO models offer 27 KW to 100 KW and momentary surge from 45 to 300 KW.",
    links: [
      "https://online-order.baumalight.com/product/generators/qc-volt600",
    ],
    questions: [
      "120/240 Single Phase",
      "120/208 Volt 3-Phase",
      "120/240 Volt 3-Phase",
      "480 Volt 3-Phase",
    ],
  },
  Excavators: {
    description: "We have a wide variety of Attachments in Excavators.",
    questions: [
      "Stump Grinder Excvator",
      "Brush Mulchers Excvator",
      "Tree Shears Excvator",
      "Tree Saw Excvator",
      "Feller Buncher Excvator",
      "Stump Planer Excvator",
      "Rotary Brush Cutter Excvator",
      "Screw Splitters Excvator",
    ],
  },
  "Stump Grinder Excvator": {
    description:
      "Excavator stump grinder is designed with high performance in mind for 1.5 to 4 ton excavators equipped with 8 to 40 gallons per minute of flow. It features 24 round carbide teeth.",
    links: [
      "https://online-order.baumalight.com/product/stump-grinder/gxm-350",
    ],
    questions: ["GXM350", "GXM550", "GXM750", "S14-Excvator", "S18-Excvator"],
  },
  GXM350: {
    description:
      "The GXM350 excavator stump grinder is designed with high performance in mind for 1.5 to 4 ton excavators equipped with 8 to 40 gallons per minute of flow. It features 24 round carbide teeth. The high speed Teeth can be rotated for a fresh edge up to three times, letting you grind stumps 3 times longer.",
    links: [
      "https://online-order.baumalight.com/product/stump-grinder/gxm-350",
    ],
    questions: ["GXM550", "GXM750", "S14-Excvator", "S18-Excvator"],
  },
  GXM550: {
    description:
      "The GXM550 excavator stump grinder is designed with high performance in mind for 3.5 to 8 ton excavators equipped with 8 to 40 gallons per minute of flow. It features 12 round carbide teeth packed in groups of 3. The high speed Teeth can be rotated for a fresh edge up to three times, letting you grind stumps 3 times longer.",
    links: [
      "https://online-order.baumalight.com/product/stump-grinder/gxm-550",
    ],
    questions: ["GXM350", "GXM750", "S14-Excvator", "S18-Excvator"],
  },
  GXM750: {
    description:
      "The GXM750 excavator stump grinder is designed with high performance in mind for 7 to 18 ton excavators equipped with 8 to 40 gallons per minute of flow. It Features 12 round carbide teeth packed in groups of 3. The high speed Teeth can be rotated for a fresh edge up to three times, letting you grind stumps 3 times longer.",
    links: [
      "https://online-order.baumalight.com/product/stump-grinder/gxm-750",
    ],
    questions: ["GXM350", "GXM550", "S14-Excvator", "S18-Excvator"],
  },
  "S14-Excvator": {
    description:
      "The S14 skid steer stump grinder is designed to go on both mini skidsteers and mini excavators. With a quick pull of two pins, a standard size skidsteer plate can be put on as well. The direct flow hydraulic drive is designed to provide the best torque and RPM to the cutting head as no flow is diverted to a swing cylinder.",
    links: ["https://online-order.baumalight.com/product/stump-grinder/ex-s14"],
    questions: ["GXM350", "GXM550", "GXM750", "S18-Excvator"],
  },
  "S18-Excvator": {
    description:
      "The S18 skid steer stump grinder is designed to go on both skidsteers and small excavators. With a quick pull of two pins, a standard size skidsteer plate can be put on as well. The direct flow hydraulic drive is designed to provide the best torque and RPM to the cutting head as no flow is diverted to a swing cylinder.",
    links: ["https://online-order.baumalight.com/product/stump-grinder/ex-s18"],
    questions: ["GXM350", "GXM550", "GXM750", "S14-Excvator"],
  },
  "Brush Mulchers Excvator": {
    description:
      "The heart of a Brush Mulcher system is the design of the rotor. Rows of teeth are placed in dual staggered spirals delivering a fine mulch. Each tooth is carbide tipped and bolt on replaceable for easy servicing, even in the field.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers-en"],
    questions: [
      "MX230",
      "MX330",
      "MX530",
      "MX548R",
      "MX530R",
      "MX948R",
      "MX960R",
      "MX1160R",
    ],
  },
  MX230: {
    description:
      "the MX230 flail cutter will efficiently cut heavy grass and small diameter brush using 22 flail teeth. Flail teeth will swing back when hitting stones so less damage is done to the flail tooth. ",
    links: ["https://online-order.baumalight.com/product/brush-mulchers/mx230"],
    questions: [
      "MX330",
      "MX530",
      "MX548R",
      "MX530R",
      "MX948R",
      "MX960R",
      "MX1160R",
    ],
  },
  MX330: {
    description:
      "the MX330 brush mulcher will efficiently cut heavy vegetation and light brush using high speed teeth. The concave shaped carbide tip provides aggressive brush mulching action by chipping the brush bit by bit.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers/mx330"],
    questions: [
      "MX230",
      "MX530",
      "MX548R",
      "MX530R",
      "MX948R",
      "MX960R",
      "MX1160R",
    ],
  },
  MX530: {
    description:
      "Our 500 series fixed tooth brush mulchers for excavators are designed to maintain and clear fence lines on farms and entry level contractor work. The 500 series Baumalight brush mulchers will efficiently mulch heavy brush and small trees and are offered with two different type of teeth. The Planer style teeth the units are shipped with, take small bites and provide the most efficient mulching and cutting.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers/mx530"],
    questions: [
      "MX230",
      "MX330",
      "MX548R",
      "MX530R",
      "MX948R",
      "MX960R",
      "MX1160R",
    ],
  },
  MX548R: {
    description:
      "The MX548R is a brush mulcher for excavators, designed to maintain and clear fence lines and entry level contractor work. The difference is aggressive root rake ripper teeth build into the frame to rip out rocks and move logs and has a heavier duty body built with AR400 steel that is the same weight but much stronger than mild steel.",
    links: [
      "https://online-order.baumalight.com/product/brush-mulchers/mx548r",
    ],
    questions: [
      "MX230",
      "MX330",
      "MX530",
      "MX530R",
      "MX948R",
      "MX960R",
      "MX1160R",
    ],
  },
  MX530R: {
    description:
      "The MX530R is a brush mulcher for excavators and designed to maintain and clear fence lines and entry level contractor work. The difference is the built-in to frame root rake to move logs and other debris out of the path of the excavator or field of work. ",
    links: [
      "https://online-order.baumalight.com/product/brush-mulchers/mx530r",
    ],
    questions: [
      "MX230",
      "MX330",
      "MX530",
      "MX548R",
      "MX948R",
      "MX960R",
      "MX1160R",
    ],
  },
  MX948R: {
    description:
      "The Baumalight MX948R Brush Mulcher has a 48” rotor and is designed for excavators starting at 12 tons. With a 70” path, the MX948R uses a fixed tooth holder and has 27 heavy duty double carbide tipped teeth (R9000) that are ideal for clearing heavy brush and trees.",
    links: [
      "https://online-order.baumalight.com/product/brush-mulchers/mx948r",
    ],
    questions: [
      "MX230",
      "MX330",
      "MX530",
      "MX548R",
      "MX530R",
      "MX960R",
      "MX1160R",
    ],
  },
  MX960R: {
    description:
      "The Baumalight MX960R Brush Mulcher has a 60” rotor and is designed for excavators starting at 18 ton up to 33 tons. The MX960R uses a fixed tooth holder comes with heavy duty double carbit tipped teeth (R9000), these teeth are ideal for vegetation management with lots of ground contact and don’t mind the occasional stone.",
    links: [
      "https://online-order.baumalight.com/product/brush-mulchers/mx960r",
    ],
    questions: [
      "MX230",
      "MX330",
      "MX530",
      "MX548R",
      "MX530R",
      "MX948R",
      "MX1160R",
    ],
  },
  MX1160R: {
    description:
      "The Baumalight MX1160R Brush Mulcher has a 60” rotor and is designed for excavators up to 33 tons. The MX1160R comes with unique performance boosting mulcher rings (licensed by Denis Cimaf). These rings improve the speed and efficiency of your mulching while reducing the risk of breakage on the tooth holders by limiting the size of the bites.",
    links: [
      "https://online-order.baumalight.com/product/brush-mulchers/mx1160r",
    ],
    questions: [
      "MX230",
      "MX330",
      "MX530",
      "MX548R",
      "MX530R",
      "MX948R",
      "MX960R",
    ],
  },
  "Tree Shears Excvator": {
    description:
      "Baumalight offers Tree Shears for both skidsteer mount and excavator mount and has many models and configurations to help with your vegetation management and land clearing requirements.",
    links: ["https://online-order.baumalight.com/product/tree-shears-en"],
    questions: ["IXP508G", "IXP510G", "IXP51G2"],
  },
  IXP508G: {
    description:
      "The IXP508G pivoting tree shear models offer a full 90 degree radius, giving you the versatility to fell up to 8 inch diameter trees in the upright position or cut limbs horizontally. Designed for 3 – 10 ton excavators.",
    links: ["https://online-order.baumalight.com/product/tree-shears/ixp508g"],
    questions: ["IXP510G", "IXP51G2"],
  },
  IXP510G: {
    description:
      "The IXP510G pivoting tree shear models offer a full 90 degree radius, giving you the versatility to fell up to 10 inch diameter trees in the upright position or cut limbs horizontally. Designed for 5 – 15 ton excavators.",
    links: ["https://online-order.baumalight.com/product/tree-shears/ixp510g"],
    questions: ["IXP508G", "IXP51G2"],
  },
  IXP51G2: {
    description:
      "The IXP512G pivoting tree shear models offer a full 90 degree radius, giving you the versatility to fell up to 12 inch diameter trees in the upright position or cut limbs horizontally. Designed for 8 – 20 ton excavators.",
    links: ["https://online-order.baumalight.com/product/tree-shears/ixp512g"],
    questions: ["IXP508G", "IXP510G"],
  },
  "Tree Saw Excvator": {
    description:
      "The Baumalight tree saw is a hydraulic-driven tree saw with a rotating cutting head for your skid steer or excavator or powered by the PTO on your tractor. The high-speed circular blade features replaceable carbide teeth for improved durability and precise cuts.",
    links: ["https://online-order.baumalight.com/product/tree-saw-en"],
    questions: ["DXM530", "DXA530", "DXD758", "DXD752"],
  },
  DXM530: {
    description:
      "The Baumalight DXM530 hydraulically-driven tree saw for excavators. To ensure the right angle of attack, the DXM530 features a manual rotating cutting head, allowing a 90 degree rotation from horizontal cutting to vertical cutting.",
    links: ["https://online-order.baumalight.com/product/tree-saw/dxm530"],
    questions: ["DXA530", "DXD758", "DXH752"],
  },
  DXA530: {
    description:
      "With the DXA530 DropSaw model, a multi angle tree saw for excavators, the cutting head rotates 180 degrees for quick cleaning, trimming and limbing of branches as well as cutting down small trees.",
    links: ["https://online-order.baumalight.com/product/tree-saw/dxa530"],
    questions: ["DXM530", "DXD758", "DXH752"],
  },
  DXD752: {
    description:
      'DXD752, Baumalight’s hydraulically-driven tree saw. Driving the 360° blade rotation is a powerful slew drive rotator. With a 52" diameter, 1" thick steel blade, the DXD752 tree saw quickly slices through trees up to 20" diameter.',
    links: ["https://online-order.baumalight.com/product/tree-saw/dxd752"],
    questions: ["DXM530", "DXA530", "DXH752"],
  },
  DXH752: {
    description:
      "The Baumalight tree saw is a hydraulic-driven tree saw with a rotating cutting head for your skid steer or excavator or powered by the PTO on your tractor. The high-speed circular blade features replaceable carbide teeth for improved durability and precise cuts.",
    links: ["https://online-order.baumalight.com/product/tree-saw/dxh752"],
    questions: ["DXM530", "DXA530", "DXD752"],
  },
  "Feller Buncher Excvator": {
    description:
      "Baumalight Feller Buncher is a Hot Saw that features a 52” cutting disc that can take up to 20” trees and is equipped with 18 beaver style cutting teeth. The beaver teeth are made from high-grade alloy steel, heat treated to a high Rockwell rating, while not being brittle.",
    links: ["https://online-order.baumalight.com/product/feller-buncher-en"],
    questions: ["FBXD572"],
  },
  FBXD572: {
    description:
      "BWe are working to design a number of Feller Buncher models and welcome feed back in exchange for preproduction discounts. Our goal is to sell through dealers and then work with end users to develop compact harvesting solutions for skid steers and medium sized excavators.",
    links: [
      "https://online-order.baumalight.com/product/feller-buncher/fbxd752",
    ],
  },
  "Stump Planer Excvator": {
    description:
      "Stump Planer tool, designed for excavators and skidsteers, operates at a low RPM so that chips are contained during the operation with very little mess to clean up. Ideal for urban areas or confined spaces.",
    links: ["https://online-order.baumalight.com/product/generators-en"],
    questions: ["RSX380", "RSX580", "RSX780"],
  },
  "Stump Planer": {
    description:
      "Stump Planer tool, designed for excavators and skidsteers, operates at a low RPM so that chips are contained during the operation with very little mess to clean up. Ideal for urban areas or confined spaces.",
    links: ["https://online-order.baumalight.com/product/generators-en"],
    questions: ["RSX380", "RSX580", "RSX780"],
  },
  RSX380: {
    description:
      "The RSX excavator models have a Stump Planer tool that is designed to bolt on to your excavator. The RSX model operates at a low RPM so that chips are contained during the operation with very little mess to clean up.",
    links: [
      "https://online-order.baumalight.com/product/stump-planer/planer-rsx380",
    ],
    questions: ["RSX580", "RSX780"],
  },
  RSX580: {
    description:
      "The RSX excavator models have a Stump Planer tool that is designed to bolt on to your excavator. The RSX model operates at a low RPM so that chips are contained during the operation with very little mess to clean up.",
    links: [
      "https://online-order.baumalight.com/product/stump-planer/planer-rsx580",
    ],
    questions: ["RSX380", "RSX780"],
  },
  RSX780: {
    description:
      "The RSX excavator models have a Stump Planer tool that is designed to bolt on to your excavator. The RSX model operates at a low RPM so that chips are contained during the operation with very little mess to clean up.",
    links: [
      "https://online-order.baumalight.com/product/stump-planer/planer-rsx780",
    ],
    questions: ["RSX380", "RSX580"],
  },
  "Rotary Brush Cutter Excvator": {
    description:
      "The Rotary Brush Cutter is a heavy-duty rotary brush mower designed to efficiently destroy dense vegetation. Capable of taking on the stringy, dense undergrowth and has a heavy duty solid frame which is meant for rough terrain.",
    links: ["https://online-order.baumalight.com/product/cutters-en"],
    questions: ["CXC530", "CXC542", "CXC550"],
  },
  CXC530: {
    description:
      "Taking the Rotary Brush Cutter to new heights is the 30” compact CXC530 model for mini-excavators. Built to help you tackle the areas with limited access, the CXC530’s unique blade design attacks and cuts thick brush, reducing it to mulch.",
    links: ["https://online-order.baumalight.com/product/cutters/cxc530"],
    questions: ["CXC542", "CXC550"],
  },
  CXC542: {
    description:
      'The 42" Industrial excavator mounted Rotary Brush Cutter CXC542 model is offered for mid-range excavators. Built much like the CXC550, the same bearing support is used with only the frame and rotor smaller for less weight to go on smaller excavators.',
    links: ["https://online-order.baumalight.com/product/cutters/cxc542"],
    questions: ["CXC530", "CXC550"],
  },
  CXC550: {
    description:
      "Taking the Rotary Brush Cutter to new heights is the 50” Industrial CXC550 model for mid-range excavators. Built to help you tackle the areas with limited access, the CXC550’s unique blade design attacks and cuts thick brush, reducing it to mulch. The reversible blades provide long performance before requiring sharpening or replacement.",
    links: ["https://online-order.baumalight.com/product/cutters/cxc550"],
    questions: ["CXC530", "CXC542"],
  },
  "Screw Splitters Excvator": {
    description:
      "Splinter’s Log Splitter tool can split pieces of wood and logs up to 12 feet or even 20 ft long. Designed to be mounted on excavators or skidsteers, the log splitter’s power comes from the hydraulically-driven motor mounting on a planetary drive, delivering a high amount of torque to the splitting head.",
    links: ["https://online-order.baumalight.com/product/screw-splitters-en"],
    questions: ["RSX380", "RSX580", "RSX780"],
  },
  Augers: {
    description:
      "Baumalight auger drives come in a variety of sizes, with torque ratings from 249 ft/lbs up to 4,006 ft/lbs. These hydraulic-driven auger drives are ruggedly built and available with a variety of mounting options, drive sizes and a wide range of interchangable auger bits.",
    links: ["https://online-order.baumalight.com/product/auger-drive-en"],
    questions: ["Owner Operator", "Contractor Series"],
  },
  "Owner Operator": {
    description:
      "Put down your shovel and turn your skid steer or mini excavator into a post hole driller. Baumalight’s RC442 auger drive is designed to handle a variety of hole-drilling needs; from planting trees to digging fence holes.",
    links: ["https://online-order.baumalight.com/product/augers/rc442"],
    questions: ["RC442", "RC582"],
  },
  RC442: {
    description:
      "Put down your shovel and turn your skid steer or mini excavator into a post hole driller. Baumalight’s RC442 auger drive is designed to handle a variety of hole-drilling needs; from planting trees to digging fence holes.",
    links: ["https://online-order.baumalight.com/product/augers/rc442"],
    questions: ["RC582"],
  },
  RC582: {
    description:
      "RC582 is designed for mini-skid steers, skid steers (up to 6000 lbs) and mini excavators (up to 6000 lbs). Designed with a 2” hex drive for long life and durability, the RC582 offers high torque for tough jobs, a heavy-duty universal joint, and a bolt-on bit for quick auger bit changes.",
    links: ["https://online-order.baumalight.com/product/augers/rc582"],
    questions: ["RC442"],
  },
  RC586: {
    description:
      "RC586 auger drive has a heavy duty planetary 2” hex drive and a 1½“ pivot pin with brass bushings. For exceptional performance, the RC586 has a heavy duty frame and a 6:1 gear ratio.",
    links: ["https://online-order.baumalight.com/product/augers/rc586"],
    questions: ["RC780"],
  },
  RC780: {
    description:
      "Baumalight’s RC780 auger drive mounts on your skid steer or excavator. Available with a variety of bit options, the RC780 is ideal for digging post holes, planting trees, planting stumps or breaking up rocks. Available for up to 12,000 lb skid steers or up to 30,000 lb excavators.",
    links: ["https://online-order.baumalight.com/product/augers/rc780"],
    questions: ["RC586"],
  },
  "Contractor Series": {
    description:
      "RC586 auger drive has a heavy duty planetary 2” hex drive and a 1½“ pivot pin with brass bushings. For exceptional performance, the RC586 has a heavy duty frame and a 6:1 gear ratio.",
    links: ["https://online-order.baumalight.com/product/augers/rc586"],
    questions: ["RC586", "RC780"],
  },
  "Screw Spliters": {
    description:
      "Splinter’s Log Splitter tool can split pieces of wood and logs up to 12 feet or even 20 ft long. Designed to be mounted on excavators or skidsteers, the log splitter’s power comes from the hydraulically-driven motor mounting on a planetary drive, delivering a high amount of torque to the splitting head.",
    links: ["https://online-order.baumalight.com/product/screw-splitters-en"],
  },
  "Teeth Options": {
    description:
      "At Baumalight, we design our attachments to handle heavy mulching, grinding and mowing, and to ensure high performance under heavy use, we supply the best teeth for the job. We offer a large selection of heavy duty fixed, bolt-in, or replaceable teeth for stump grinding, mulching, mowing or cutting.",
    links: ["https://online-order.baumalight.com/product/teeth-options-en"],
  },
  Tractors: {
    description: "We have a wide variety of Attachments in Tractors.",
    questions: [
      "Stump Grinder Tractor",
      "Brush Mulchers Tractor",
      "Tree Spades Tractor",
      "Tree Saw Tractor",
      "Trenchers Tractor",
      "Flail Mowers Tractor",
      "Rotary Brush Cutter Tractor",
    ],
  },
  "Stump Grinder Tractor": {
    description:
      'stump grinder is designed for small tractors equipped with hydrostatic drive and Category 1 3PH. This tractor mounted stump grinder model allows you to grind small and midsized stumps efficiently with a 24" Rotor, carrying 34 replaceable carbide teeth and has a cutting depth of 10" above ground and 6" below ground with the cutting wheel speed of 540 RPM. The carbide tipped teeth is 3/4-inch-thick.',
    links: ["https://online-order.baumalight.com/product/stump-grinder/1p-24"],
    questions: ["1P24", "3P24", "3P34", "3P40"],
  },
  "1P24": {
    description:
      'stump grinder is designed for small tractors equipped with hydrostatic drive and Category 1 3PH. This tractor mounted stump grinder model allows you to grind small and midsized stumps efficiently with a 24" Rotor, carrying 34 replaceable carbide teeth and has a cutting depth of 10" above ground and 6" below ground with the cutting wheel speed of 540 RPM. The carbide tipped teeth is 3/4-inch-thick.',
    links: ["https://online-order.baumalight.com/product/stump-grinder/1p-24"],
    questions: ["3P24", "3P34", "3P40"],
  },
  "3P24": {
    description:
      'The 3P24 PTO stump grinder is designed for tractors equipped with a 30–50 horse power motor allowing you to grind into stumps with a 24" rotor carrying 34 replaceable carbide teeth. The cutting and lifting cylinders are powered by your tractor’s hydraulic remotes.',
    links: ["https://online-order.baumalight.com/product/stump-grinder/3p-24"],
    questions: ["1P24", "3P34", "3P40"],
  },
  "3P34": {
    description:
      'The 3P34 PTO stump grinder is designed for tractors equipped with a 50–80 horse power motor allowing you to grind into stumps with a 34" Rotor carrying 52 replaceable carbide teeth. The Stump Blaster’s carbide teeth extend a full 1-¼ inches from the rotor. This prevents chips and mulch from getting plugged. The rugged gear box takes up to 80 HP and develops 803 ft/lbs of stump destroying torque. A stump of 30" width and 12" depth can be ground in 4 mins with a 80HP tractor, with 70HP it takes around 5 mins and 60 HP takes 6 mins to finish the work.',
    links: ["https://online-order.baumalight.com/product/stump-grinder/3p-34"],
    questions: ["1P24", "3P24", "3P40"],
  },
  "3P40": {
    description:
      'The 3P40 HPR PTO stump grinder is designed with high performance in mind, for tractors equipped with a 60–120 HP and 1,000 RPM PTO.The rugged Stump Blaster gear box transfers power from the tractor’s PTO to the rotor creating 803 Ft.-Lbs of torque turning the rotor and hungry teeth at 810 RPM. This stump grinder will devour large tree stumps with its 52 replaceable carbide teeth and a 34" rotor.',
    links: ["https://online-order.baumalight.com/product/stump-grinder/3p-40"],
    questions: ["1P24", "3P24", "3P34"],
  },
  "Brush Mulchers Tractor": {
    description:
      "Brush Mulcher on the PTO of a tractor is the most efficient way to run a brush mulcher and if you check our brush cutting size charts you will see that the slower you can travel the bigger material you can handle. ",
    links: ["https://online-order.baumalight.com/product/brush-mulchers-en"],
    questions: ["MP348", "MP360", "MP560", "MP572", "MP972"],
  },
  MP348: {
    description:
      "MP348 brush mulcher will efficiently cut heavy vegetation and light brush using high speed teeth. The concave shaped carbide tip provides aggressive brush mulching action by chipping the brush bit by bit. Part of the secret of their performance is the ease of rotating the teeth so there is always a sharp edge to make mulching easier.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers/mp348"],
    questions: ["MP360", "MP560", "MP572", "MP972"],
  },
  MP360: {
    description:
      "MP360 brush mulcher will efficiently cut heavy vegetation and light brush using high speed teeth. The concave shaped carbide tip provides aggressive brush mulching action by chipping the brush bit by bit. Part of the secret of their performance is the ease of rotating the teeth so there is always a sharp edge to make mulching easier.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers/mp360"],
    questions: ["MP348", "MP560", "MP572", "MP972"],
  },
  MP560: {
    description:
      " MP560 and bigger sizes of tractor mount mulchers is the opening cutting shield. This allows you to adjust for a better, higher angle of attack on bigger brush or keep it closed and control the mulch for even finer results.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers/mp560"],
    questions: ["MP348", "MP360", "MP572", "MP972"],
  },
  MP572: {
    description:
      "Our 500 series fixed tooth brush mulchers for 3-point hitch tractors are designed to maintain and clear fence lines on farms and entry level contractor work. The 500 series Baumalight brush mulchers will efficiently mulch heavy brush and small trees and are offered with two different types of teeth.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers/mp572"],
    questions: ["MP348", "MP360", "MP560", "MP972"],
  },
  MP972: {
    description:
      "The MP972 masticating head Brush Mulcher is designed to fit tractors with 90 - 135 HP and Cat 2 or 3 3PH. The 900 Series teeth are available in either Ripper or Planer style. The carbide Ripper tooth is the good general use tooth. Their v-shaped design shreds through brush and makes them less vulnerable in areas plagued by rocks and debris.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers/mp972"],
    questions: ["MP348", "MP360", "MP560", "MP572"],
  },
  "Tree Saw Tractor": {
    description:
      "Baumalight tree saw is a hydraulic-driven tree saw with a rotating cutting head for your skid steer or excavator or powered by the PTO on your tractor. The high-speed circular blade features replaceable carbide teeth for improved durability and precise cuts.",
    links: ["https://online-order.baumalight.com/product/tree-saw-en"],
    questions: ["DPH530", "DPH735"],
  },
  DPH530: {
    description:
      "The DPH530 tractor mounted tree saw is a small unit useful to develop farmland, clean up fence lines, woodlot and pasture cleanup solutions. This power take off tree saw features a 30” cutting disc that can take up to 9.5” trees with rotatable high speed teeth.",
    links: ["https://online-order.baumalight.com/product/tree-saw/dph530"],
    questions: ["DPH735"],
  },
  DPH735: {
    description:
      "We are working to design a number of tractor mounting PTO powered tree saw models and welcome feed back in exchange for preproduction discounts. Our goal is to sell through dealers and then work with end users on feedback and product improvement.",
    links: ["https://online-order.baumalight.com/product/tree-saw/dph735"],
    questions: ["DPH530"],
  },
  "Tree Spades Tractor": {
    description:
      "Trees are the anchor to any landscape, providing shelter, shade and beauty. With the Baumalight line of tree spades and transplanting products, you can position and plant your tree exactly where you want.",
    links: ["https://online-order.baumalight.com/product/tree-spades-en"],
    questions: ["PT324", "PT330", "PS330", "PT440", "PT650"],
  },
  PT324: {
    description:
      "The PT324 Small Fixed Compact tree spade features three blades to give you the digging and root ball compacting action necessary for cleaner and more viable transplants.",
    links: ["https://online-order.baumalight.com/product/tree-spades/pt324"],
    questions: ["PT330", "PS330", "PT440", "PT650"],
  },
  PT330: {
    description:
      "The three-blade fixed frame Baumalight PT330 tree spade is designed to simplify tree transplanting. Featuring uncomplicated controls and a rugged frame, the PT330 is ready to attach to standard 3-point hitch connection.",
    links: ["https://online-order.baumalight.com/product/tree-spades/pt330"],
    questions: ["PT324", "PS330", "PT440", "PT650"],
  },
  PS330: {
    description:
      'The Baumalight PS330 adds a hinged frame arm for easy positioning and less damage to lower branches. This three-blade tree spade can handle trees up to 3" in diameter. The rear spades on either side of the operator provide the best possible view of the spading operations.',
    links: ["https://online-order.baumalight.com/product/tree-spades/ps330"],
    questions: ["PT324", "PT330", "PT440", "PT650"],
  },
  PT440: {
    description:
      "Baumalight PT440 tree spade stand out. The wide blade position gives the operator a comfortable and clear view of the spading action, which is incredibly important when transplanting evergreen trees and minimizing damage to the lower branches.",
    links: ["https://online-order.baumalight.com/product/tree-spades/pt440"],
    questions: ["PT324", "PT330", "PS330", "PT650"],
  },
  PT650: {
    description:
      "Baumalight PT650 tree spade to open up, and hug the tree for accurate positioning and to prevent damage to lower branches. The six blades deliver easier spading, cleaner cuts and a better root ball for a more viable transplant.",
    links: ["https://online-order.baumalight.com/product/tree-spades/pt650"],
    questions: ["PT324", "PT330", "PS330", "PT440"],
  },
  "Trenchers Tractor": {
    description:
      'Baumalight Trencher is designed to carve a safe haven for your cables and lines. Ideal for rural property owners, landscapers or contractors, Baumalight Trenchers quickly and efficiently carve trenches from 4" to 10" wide and up to 5 feet deep.',
    links: ["https://online-order.baumalight.com/product/trenchers-en"],
    questions: ["TNS336", "TN548"],
  },
  TNS336: {
    description:
      "Baumalight TNS336 Trencher. Rural property owners, landscapers or profesional contractors can quickely cut trenches up to 36” deep and between 4” to 6” wide, depending on the chain option. The TNS336 Trencher is powered by a planetary drive system.",
    links: [
      "https://online-order.baumalight.com/product/trenchers/tractor-tns336",
    ],
    questions: ["TN548"],
  },
  TN548: {
    description:
      "Baumalighnt’s TN548 is up for the job. Quickly and safely bury valuable cables and utility lines underground and out of harm’s way. The TN548 Trencher will easily cut trenches up to 48” deep and between 6” to 10” wide, depending on the chain option.",
    links: [
      "https://online-order.baumalight.com/product/trenchers/tractor-tn548",
    ],
    questions: ["TNS336"],
  },
  "Flail Mowers Tractor": {
    description:
      "Baumalight Flail Mower is the good attachment for the job. With models available for a compact tractor or a mini skidsteer, our Flail Mowers are compact and perfect for maneuvering around objects and mowing in tight spaces.",
    links: ["https://online-order.baumalight.com/product/flail-mowers-en"],
    questions: ["FMP260"],
  },
  FMP260: {
    description:
      " FMP260 will efficiently cut long, heavy grass or short diameter brush. The FMP260 is equipped with 30 F2000 flail style teeth which will swing back when hitting stones, so less damage is done to the teeth.",
    links: ["https://online-order.baumalight.com/product/flail-mowers/fmp260"],
  },
  "Rotary Brush Cutter Tractor": {
    description:
      "The Rotary Brush Cutter is a heavy-duty rotary brush mower designed to efficiently destroy dense vegetation. Capable of taking on the stringy, dense undergrowth and has a heavy duty solid frame which is meant for rough terrain.",
    links: ["https://online-order.baumalight.com/product/cutters-en"],
    questions: ["CP560", "CP572"],
  },
  CP560: {
    description:
      "CP560 tractor mount 60” rotary brush cutter. The Brush Bar helps to funnel brush under the Rotary Brush Cutter to the waiting blades. The double arch design of the push bar works to pull the taller, heavier brush to the hardened blades, making quick work of woody brush and saplings.",
    links: ["https://online-order.baumalight.com/product/cutters/cp560"],
    questions: ["CP572"],
  },
  CP572: {
    description:
      "CP572 tractor mount 72” rotary brush cutter. The Brush Bar helps to funnel brush under the Rotary Brush Cutter to the waiting blades. The double arch design of the push bar works to pull the taller, heavier brush to the hardened blades, making quick work of woody brush and saplings.",
    links: ["https://online-order.baumalight.com/product/cutters/cp572"],
    questions: ["CP560"],
  },
  Skidsteers: {
    description: "We have a wide variety of Attachments in Skidsteers.",
    questions: [
      "Stump Grinder Skidsteers",
      "Christmas Tree Stump Grinder",
      "Brush Mulchers Skidsteers",
      "Tree Shears Skidsteers",
      "Tree Saw Skidsteer",
      "Tree Spades Skidsteers",
      "Trenchers Skidsteers",
      "Feller Buncher Skidsteer",
      "Stump Planner Skidsteer",
      "Rotary Brush Cutter Skidsteers",
      "Boom Mower Skidsteers",
      "Screw Splitters Skidsteers",
    ],
  },
  "Stump Grinder Skidsteers": {
    description:
      "Baumalight stump grinder line-up includes attachments for many carriers, 3 point hitch stump grinders for tractors, stump grinders for skidsteers, and stump grinder attachments for excavators and backhoes. Self propelled stump grinders, as well as walk behind stumpgrinders, are also offered.",
    links: ["https://online-order.baumalight.com/product/stump-grinder-en"],
    questions: ["S14", "S16", "S18", "S22", "S24", "S28", "S14"],
  },
  S14: {
    description:
      "The S14 skid steer stump grinder is designed with simple operation in mind, with no required electrical connection. The direct flow hydraulic drive is designed to provide the best torque and RPM to the cutting head as no flow is diverted to a swing cylinder.",
    links: ["https://online-order.baumalight.com/product/stump-grinder/s14"],
    questions: ["S16", "S18", "S22", "S24", "S28", "S40"],
  },
  S16: {
    description:
      "The S16 Skidsteer stump grinder features a specially designed electric actuator that controls the swing of the stump grinder. Equipped with high-performance electric linear actuators (12VDC) and limit switches, the actuator body is made of 304 stainless steel and has an IP69 rating.",
    links: ["https://online-order.baumalight.com/product/stump-grinder/s16"],
    questions: ["S14", "S18", "S22", "S24", "S28", "S40"],
  },
  S18: {
    description:
      "The S18 skid steer stump grinder is designed ruggedly with simple operation in mind, with no required electrical connection. The simple direct flow hydraulic drive is designed to provide the best torque and RPM to the cutting head as no flow is diverted to a swing cylinder.",
    links: ["https://online-order.baumalight.com/product/stump-grinder/s18"],
    questions: ["S14", "S16", "S22", "S24", "S28", "S40"],
  },
  S22: {
    description:
      "The Baumalight S22 stump grinder mounts on a full-sized skidsteer using the universal skidsteer adapter, ensuring compatibility and convenience of usage. Each S22 Stump Grinder comes with a complimentary set of six replacement teeth, conveniently shipped for hassle-free maintenance.",
    links: ["https://online-order.baumalight.com/product/stump-grinder/s22"],
    questions: ["S14", "S16", "S18", "S24", "S28", "S40"],
  },
  S24: {
    description:
      "The S24 skid steer stump grinder features a specially designed 12V diverter valve to allow control of the hydraulic swing cylinder, for a more refined cutting pass. Combined with our flow control this remote will give you precise control of the cutting pass and allow you to grind more of the stump without repositioning.",
    links: ["https://online-order.baumalight.com/product/stump-grinder/s24"],
    questions: ["S14", "S16", "S18", "S22", "S28", "S40"],
  },
  S28: {
    description:
      "The S28 skid steer stump grinder is designed for high flow and higher horsepower skid steers. Baumalight’s most powerful model, the S28 adds a high volume hydraulic motor and a gearbox that increases the torque to the cutting head giving you the best of precision, power and speed in your stump grinding.",
    links: ["https://online-order.baumalight.com/product/stump-grinder/s28"],
    questions: ["S14", "S16", "S18", "S22", "S24", "S40"],
  },
  S40: {
    description:
      "The S40 stump grinder is mounted with a bent axis piston motor. By matching a motor to your skid steers hydraulic flow these high efficiency motors make the most hydraulic power transforming it into the highest available stump grinding performance. Stocked with 12 High speed teeth the massive 1.25” thick steel rotor provides the back bone for the Skidsteer mounted stump grinder.",
    links: ["https://online-order.baumalight.com/product/stump-grinder/s40"],
    questions: ["S14", "S16", "S18", "S22", "S24", "S28"],
  },
  "Christmas Tree Stump Grinder": {
    description:
      "Baumalight stump grinder line-up includes attachments for many carriers, 3 point hitch stump grinders for tractors, stump grinders for skidsteers, and stump grinder attachments for excavators and backhoes. Self propelled stump grinders, as well as walk behind stumpgrinders, are also offered.",
    links: ["https://online-order.baumalight.com/product/stump-grinder-en"],
    questions: ["S14", "S16", "S18", "S22", "S24", "S28", "S14"],
  },
  "Brush Mulchers Skidsteers": {
    description:
      "The heart of a Brush Mulcher system is the design of the rotor. Rows of teeth are placed in dual staggered spirals delivering a fine mulch. Each tooth is carbide tipped and bolt on replaceable for easy servicing, even in the field.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers-en"],
    questions: [
      "MS348",
      "MS530M",
      "MS548",
      "MS560",
      "MS572",
      "MS960",
      "MS972",
      "MS530M",
    ],
  },
  MS348: {
    description:
      "Our most light weight fixed tooth brush mulcher for skid steers. With adequate flow, the MS348 brush mulcher will efficiently cut heavy vegetation and light brush using high speed teeth. The concave shaped carbide tip provides aggressive brush mulching action by chipping the brush bit by bit.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers/ms348"],
    questions: [
      "MS530M",
      "MS548",
      "MS560",
      "MS572",
      "MS960",
      "MS972",
      "MS530M",
    ],
  },
  MS530M: {
    description:
      "The MS530M Brush Mulcher is a heavy-duty, versatile Mini Skidsteer mulcher built for efficient mulching and clearing of brush, trees, and vegetation. It features an integrated push bar to control and bend taller brush, along with adjustable skid shoes for optimal cutting height.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers-en"],
    questions: ["MS348", "MS548", "MS560", "MS572", "MS960", "MS972", "MS530M"],
  },
  MS548: {
    description:
      "The 500 series Baumalight brush mulchers will efficiently mulch heavy brush and small trees and are offered with two different types of teeth. The Planer style teeth take small bites and provide the most efficient mulching and cutting.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers/ms548"],
    questions: [
      "MS348",
      "MS530M",
      "MS560",
      "MS572",
      "MS960",
      "MS972",
      "MS530M",
    ],
  },
  MS348: {
    description:
      "The 500 series Baumalight brush mulchers will efficiently mulch heavy brush and small trees and are offered with two different types of teeth. The Planer style teeth take small bites and provide the most efficient mulching and cutting.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers/ms560"],
    questions: [
      "MS348",
      "MS530M",
      "MS548",
      "MS572",
      "MS960",
      "MS972",
      "MS530M",
    ],
  },
  MS572: {
    description:
      "The 500 series Baumalight brush mulchers will efficiently mulch heavy brush and small trees and are offered with two different types of teeth. The Planer style teeth take small bites and provide the most efficient mulching and cutting.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers/ms572"],
    questions: [
      "MS348",
      "MS530M",
      "MS548",
      "MS560",
      "MS960",
      "MS972",
      "MS530M",
    ],
  },
  MS960: {
    description:
      "The MS960 Baumalight brush mulcher is a 60” heavy duty bush mulcher with a 75” Path width and it has turned into a very popular model for mulching with average to large skidsteers. The 900 Series teeth are available in either Double Carbide Tipped Ripper or Single Blade Planer style.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers/ms960"],
    questions: [
      "MS348",
      "MS530M",
      "MS548",
      "MS560",
      "MS572",
      "MS972",
      "MS530M",
    ],
  },
  MS972: {
    description:
      "The MS972 Baumalight brush mulcher is much like our MS960 only wider featuring a 72” rotor and 84” path width.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers/ms972"],
    questions: [
      "MS348",
      "MS530M",
      "MS548",
      "MS560",
      "MS572",
      "MS960",
      "MS530M",
    ],
  },
  MS1196: {
    description:
      "The Baumalight MS1160 Brush Mulcher has a 75” mulching path and is designed for skidsteers with a 7,000 lb minimum weight. The MS1160 comes with unique performance boosting mulcher rings (licensed by Denis Cimaf) and is powered by a bent axis piston motor.",
    links: ["https://online-order.baumalight.com/product/brush-mulchers-en"],
    questions: ["MS348", "MS530M", "MS548", "MS560", "MS572", "MS960", "MS972"],
  },
  "Flail Mowers Skidsteer": {
    description:
      "Baumalight Flail Mower is the good attachment for the job. With models available for a compact tractor or a mini skidsteer, our Flail Mowers are compact and perfect for maneuvering around objects and mowing in tight spaces. Each Flail Mower ships standard with F2000 flail style teeth which will swing back when hitting stones, so less damage is done to the teeth.",
    links: ["https://online-order.baumalight.com/product/flail-mowers-en"],
    questions: ["FEB700", "FMM148"],
  },
  FEB700: {
    description:
      "The Baumalight FEB700 flail mower is a heavy duty and versatile agricultural tool designed for efficiently mowing and mulching a variety of vegetation, including grass, weeds, light brush, and small trees. The mower features a sturdy frame that is designed to withstand the rigors of demanding work environments, making it ideal for use in agricultural, commercial, and municipal applications.",
    links: ["https://online-order.baumalight.com/product/flail-mowers/feb700"],
    questions: ["FMM148"],
  },
  FMM148: {
    description:
      "FMM148 will efficiently cut long, heavy grass or short diameter brush. The FMM148 is equipped with 30 F2000 flail style teeth which will swing back when hitting stones, so less damage is done to the teeth.",
    links: ["https://online-order.baumalight.com/product/flail-mowers/fmm148"],
    questions: ["FEB700"],
  },
  "Tree Shears Skidsteer": {
    description:
      "Baumalight offers Tree Shears for both skidsteer mount and excavator mount and has many models and configurations to help with your vegetation management and land clearing requirements. All cutting blades are built with AR400 steel and we offer charts to give estimated cutting thickness based on your pressure.",
    links: ["https://online-order.baumalight.com/product/tree-shears-en"],
    questions: ["Horizontal", "Rotating"],
  },
  Horizontal: {
    description:
      "The horizontal tree shear for 4000 lb. to 7000 lb. class skidsteers will give you the ability to shear vertical trees and saplings up to 10 inch diameter. Equipped with an individually moving grabber arm and a fixed curved cradle bar, this tree shear allows you to securely move the sheared trees and limbs to a desired safe location.",
    links: ["https://online-order.baumalight.com/product/tree-shears/ish510g"],
    questions: ["ISH510G", "ISH512G", "ISH712G"],
  },
  ISH510G: {
    description:
      "The ISH510G horizontal tree shear for 4000 lb. to 7000 lb. class skidsteers will give you the ability to shear vertical trees and saplings up to 10 inch diameter. Equipped with an individually moving grabber arm and a fixed curved cradle bar, this tree shear allows you to securely move the sheared trees and limbs to a desired safe location.",
    links: ["https://online-order.baumalight.com/product/tree-shears/ish510g"],
    questions: ["ISH512G", "ISH712G"],
  },
  ISH512G: {
    description:
      "The ISH512G horizontal tree shear for 5000 lb. to 8000 lb. class skidsteers will give you the ability to shear vertical trees and saplings up to 12 inch diameter. Equipped with an individually moving grabber arm and a fixed curved cradle bar, this tree shear allows you to securely move the sheared trees and limbs to a desired safe location.",
    links: ["https://online-order.baumalight.com/product/tree-shears/ish512g"],
    questions: ["ISH510G", "ISH712G"],
  },
  ISH712G: {
    description:
      "The ISH712G horizontal tree shear for 6000 lb. to 12000 lb. class skidsteers will give you the ability to shear vertical trees and saplings up to 12 inch diameter. Equipped with an individually moving grabber arm and a fixed curved cradle bar, this tree shear allows you to securely move the sheared trees and limbs to a desired safe location.",
    links: ["https://online-order.baumalight.com/product/tree-shears/ish712g"],
    questions: ["ISH510G", "ISH512G"],
  },
  Rotating: {
    description:
      "The ISR512 rotating tree shear is designed for 5000 lb. to 8000 lb. class skidsteers and till easily cut trees and limbs up to 12 inches in diameter. In-cab controls gives the operator the ability to rotate the cutting head a full 90 degrees, providing the versatility to fell trees in the upright position or cut limbs horizontally. This model is also equipped with an integrated brush bar to direct the limbing action..",
    links: ["https://online-order.baumalight.com/product/tree-shears/isr512"],
    questions: ["ISR512G"],
  },
  ISR512G: {
    description:
      "The ISR512 rotating tree shear is designed for 5000 lb. to 8000 lb. class skidsteers and till easily cut trees and limbs up to 12 inches in diameter. In-cab controls gives the operator the ability to rotate the cutting head a full 90 degrees, providing the versatility to fell trees in the upright position or cut limbs horizontally. This model is also equipped with an integrated brush bar to direct the limbing action.",
    links: ["https://online-order.baumalight.com/product/tree-shears/isr512"],
  },
  "Tree Saw Skidsteer": {
    description:
      "Baumalights Tree Saw is hydraulically - driven and designed for mini skidsteers.For full versatility, the cutting head can be manually rotated 90 degrees for either horizontal or vertical cutting.",
    links: ["https://online-order.baumalight.com/product/tree-saw-en"],
    questions: ["DSM230", "DSM530", "DSA530"],
  },
  DSM230: {
    description:
      "Baumalights DSM230 Tree Saw is hydraulically - driven and designed for mini skidsteers.For full versatility, the DSM230 cutting head can be manually rotated 90 degrees for either horizontal or vertical cutting.",
    links: ["https://online-order.baumalight.com/product/tree-saw/dsm230"],
    questions: ["DSM530", "DSA530"],
  },
  DSM530: {
    description:
      "DSM530 is a hydraulically-driven tree saw that can be manually rotated to cut in either horizontal or vertical position. The heavy-duty construction of the Baumalight tree saw includes a solid serrated front push bar, ideal for guiding limbs, branches and small trees safely away from the operator.",
    links: ["https://online-order.baumalight.com/product/tree-saw/dsm530"],
    questions: ["DSM230", "DSA530"],
  },
  "DSA530 ": {
    description:
      "The DSA530 model, a multi angle tree saw for skidsteers is power angled by a helical actuator, rotating the cutting head 180 degrees for quick and precise cutting, trimming and limbing.",
    links: ["https://online-order.baumalight.com/product/tree-saw/dsa530"],
    questions: ["DSM230", "DSA530"],
  },
  "Tree Spades Skidsteers": {
    description:
      "Trees are the anchor to any landscape, providing shelter, shade and beauty. With the Baumalight line of tree spades and transplanting products, you can position and plant your tree exactly where you want.",
    links: ["https://online-order.baumalight.com/product/tree-spades-en"],
    questions: [
      "X4M",
      "X4C",
      "X4S",
      "X4B",
      "ST324",
      "ST330",
      "SS330",
      "ST440",
      "ST650",
    ],
  },
  X4M: {
    description:
      "The X4M Tree Scoop is an economical way to move small trees quickly and easily. Mounted on a mini skidsteer, the X4M features a simple and rugged design that gives the operator an excellent view while planting.",
    links: ["https://online-order.baumalight.com/product/tree-spades/x4m"],
    questions: [
      "X4C",
      "X4S",
      "X4B",
      "ST324",
      "ST330",
      "SS330",
      "ST440",
      "ST650",
    ],
  },
  X4C: {
    description:
      "The X4C is the same as our other mini skid steer tree scoop except it is build with the special adaptor plate for use on a Bobcat mini skidsteer.",
    links: ["https://online-order.baumalight.com/product/tree-spades/x4c"],
    questions: [
      "X4M",
      "X4S",
      "X4B",
      "ST324",
      "ST330",
      "SS330",
      "ST440",
      "ST650",
    ],
  },
  X4S: {
    description:
      "The X4S Tree Scoop is an economical way to move small trees quickly and easily. Mounted on a skidsteer, the X4S features a simple and rugged design that gives the operator an excellent view while planting.",
    links: ["https://online-order.baumalight.com/product/tree-spades/x4s"],
    questions: [
      "X4M",
      "X4C",
      "X4B",
      "ST324",
      "ST330",
      "SS330",
      "ST440",
      "ST650",
    ],
  },
  X4B: {
    description:
      "The X4B Tree Scoop is an economical way to move small trees quickly and easily. Mounted on a skidsteer, the X4B features a simple and rugged design that gives the operator an excellent view while planting.",
    links: ["https://online-order.baumalight.com/product/tree-spades/x4b"],
    questions: [
      "X4M",
      "X4C",
      "X4S",
      "ST324",
      "ST330",
      "SS330",
      "ST440",
      "ST650",
    ],
  },
  ST324: {
    description:
      "This fixed frame hydraulic tree spade is ideal for smaller skidsteers. The ST324 Small Fixed Compact tree spade features three blades to give you the digging and root ball compacting action necessary for cleaner and more viable transplants.",
    links: ["https://online-order.baumalight.com/product/tree-spades/st324"],
    questions: ["X4M", "X4C", "X4S", "X4B", "ST330", "SS330", "ST440", "ST650"],
  },
  ST330: {
    description:
      "The three-blade fixed frame ST330 tree spade is designed to simplify tree transplanting. Featuring uncomplicated controls and a rugged frame, the ST330 is ready to get down to work.",
    links: ["https://online-order.baumalight.com/product/tree-spades/st330"],
    questions: ["X4M", "X4C", "X4S", "X4B", "ST324", "SS330", "ST440", "ST650"],
  },
  ST440: {
    description:
      "Baumalight ST440 tree spade stand out.The wide blade position gives the operator a comfortable and clear view of the spading action,which is incredibly important when transplanting evergreen trees and minimizing damage to the lower branches.The MS972 Baumalight brush mulcher is much like our MS960 only wider featuring a 72” rotor and 84” path width.",
    links: ["https://online-order.baumalight.com/product/tree-spades/st440"],
    questions: ["X4M", "X4C", "X4S", "X4B", "ST324", "ST330", "SS330", "ST650"],
  },
  ST650: {
    description:
      "ST650 tree spade to open up and hug the tree for accurate positioning and to prevent damage to lower branches. The six blades deliver easier spading, cleaner cuts and a better root ball for a more viable transplant.",
    links: ["https://online-order.baumalight.com/product/tree-spades/st650"],
    questions: ["X4M", "X4C", "X4S", "X4B", "ST324", "ST330", "SS330", "ST440"],
  },
  "Trenchers Skidsteers": {
    description:
      'Baumalight Trencher is designed to carve a safe haven for your cables and lines. Ideal for rural property owners, landscapers or contractors, Baumalight Trenchers quickly and efficiently carve trenches from 4" to 10" wide and up to 5 feet deep.',
    links: ["https://online-order.baumalight.com/product/trenchers-en"],
    questions: ["TN236", "TNS336", "TNM336B", "TN548", "TN560", "TN760"],
  },
  TN236: {
    description:
      "TN236 Trencher is small but aggressive. A great tool for landscapers, the TN236 Trencher is trencher for mini-skidsteers and mini track loaders between 1500 - 4000 lbs.",
    links: ["https://online-order.baumalight.com/product/trenchers/tn236"],
    questions: ["TNS336", "TNM336B", "TN548", "TN560", "TN760"],
  },
  TNS336: {
    description:
      "Baumalight TNS336 Trencher. Rural property owners, landscapers or profesional contractors can quickely cut trenches up to 36” deep and between 4” to 6” wide, depending on the chain option.",
    links: ["https://online-order.baumalight.com/product/trenchers/tns336"],
    questions: ["TN236", "TNM336B", "TN548", "TN560", "TN760"],
  },
  TNM336B: {
    description:
      "The TNM336B Trencher is the ideal solution for cutting trenches in tight spaces, specially designed to be compatible with Bobcat mini skid-steers.",
    links: ["https://online-order.baumalight.com/product/trenchers/tnm336b"],
    questions: ["TN236", "TNS336", "TN548", "TN560", "TN760"],
  },
  TN548: {
    description:
      "Baumalighnt’s TN548 is up for the job. Quickly and safely bury valuable cables and utility lines underground and out of harm’s way. The TN548 Trencher will easily cut trenches up to 48” deep and between 6” to 10” wide, depending on the chain option.",
    links: ["https://online-order.baumalight.com/product/trenchers/tn548"],
    questions: ["TN236", "TNS336", "TNM336B", "TN560", "TN760"],
  },
  TN560: {
    description:
      "Baumalight’s TN560 Trencher for skidsteer. Ideal or landscapers or contractors who need to safely bury gas lines, electrical line, plumbing or drainage lines.",
    links: ["https://online-order.baumalight.com/product/trenchers/tn560"],
    questions: ["TN236", "TNS336", "TNM336B", "TN548", "TN760"],
  },
  TN760: {
    description:
      "The TN760, Baumalight’s most powerful trencher for skidsteers for high flow hydraulics. Save time and money the next time you need to cut a trench to safely bury water lines, gas lines, drainage pipe or electrical lines.",
    links: ["https://online-order.baumalight.com/product/trenchers/tn760"],
    questions: ["TN236", "TNS336", "TNM336B", "TN548", "TN560"],
  },
  "Feller Buncher Skidsteer": {
    description:
      "The Skidsteer Mounted Feller Buncher we designed features a 52” cutting disc that can take up to 20” trees and is equipped with 18 Beaver cutting teeth.",
    links: [
      "https://online-order.baumalight.com/product/feller-buncher/fbs752",
    ],
    questions: ["FBS752"],
  },
  FBS752: {
    description:
      "The FBS752 Skidsteer Mounted Feller Buncher we designed features a 52” cutting disc that can take up to 20” trees and is equipped with 18 Beaver cutting teeth.",
    links: [
      "https://online-order.baumalight.com/product/feller-buncher/fbs752",
    ],
  },
  "Stump Planner Skidsteer": {
    description:
      "Skidsteer models have a Stump Planer tool that is designed to mount using a Skidsteer plate. The RSS model operates at a low RPM so that chips are contained during the operation with very little mess to clean up..",
    links: [
      "https://online-order.baumalight.com/product/stump-planer/planer-rss380",
    ],
    questions: ["RSS380", "RSS580", "RSS780"],
  },
  RSS380: {
    description:
      "RSS380 Skidsteer models have a Stump Planer tool that is designed to mount using a Skidsteer plate. The RSS model operates at a low RPM so that chips are contained during the operation with very little mess to clean up.",
    links: [
      "https://online-order.baumalight.com/product/stump-planer/planer-rss380",
    ],
    questions: ["RSS580", "RSS780"],
  },
  RSS580: {
    description:
      "RSS580 Skidsteer models have a Stump Planer tool that is designed to mount using a Skidsteer plate. The RSS model operates at a low RPM so that chips are contained during the operation with very little mess to clean up. Ideal for urban areas or confined spaces.",
    links: [
      "https://online-order.baumalight.com/product/stump-planer/planer-rss580",
    ],
    questions: ["RSS380", "RSS780"],
  },
  "RSS780 ": {
    description:
      "RSS780 Skidsteer models have a Stump Planer tool that is designed to mount using a Skidsteer plate. The RSS model operates at a low RPM so that chips are contained during the operation with very little mess to clean up. Ideal for urban areas or confined spaces.",
    links: ["https://online-order.baumalight.com/product/tree-saw/dsa530"],
    questions: ["RSS380", "RSS580"],
  },
  "Rotary Brush Cutter Skidsteers": {
    description:
      "The Rotary Brush Cutter is a heavy-duty rotary brush mower designed to efficiently destroy dense vegetation. Capable of taking on the stringy, dense undergrowth and has a heavy duty solid frame which is meant for rough terrain.",
    links: ["https://online-order.baumalight.com/product/cutters/cf360"],
    questions: ["CF360", "CF372", "CF560", "CF572", "CF772"],
  },
  CF360: {
    description:
      'CF360 heavy-duty rotary brush cutter houses two AR400 blades featuring a 70" path width. The 1/4” steel deck is designed to stand up and perform in rough terrain while cutting small trees, brush.',
    links: ["https://online-order.baumalight.com/product/cutters/cf360"],
    questions: ["CF372 ", "CF560 ", "CF572 ", "CF772 "],
  },
  CF372: {
    description:
      'CF372 heavy-duty rotary brush cutter houses two AR400 blades featuring an 82" path width. The 1/4” steel deck is designed to stand up and perform in rough terrain while cutting small trees.',
    links: ["https://online-order.baumalight.com/product/cutters/cf372"],
    questions: ["CF360", "CF560", "CF572", "CF772"],
  },
  CF560: {
    description:
      'CF560 heavy-duty rotary brush cutter houses four AR400 blades featuring an 83" path width. The 1/4” steel deck is designed to stand up and perform in rough terrain while cutting trees, brush, unwanted weeds and grass.',
    links: ["https://online-order.baumalight.com/product/cutters/cf560"],
    questions: ["CF360", "CF372", "CF572", "CF772"],
  },
  CF572: {
    description:
      'CF572 heavy-duty rotary brush cutter houses four AR400 blades featuring an 82" path width. The 1/4” steel deck is designed to stand up and perform in rough terrain while cutting trees, brush, unwanted weeds and grass.',
    links: ["https://online-order.baumalight.com/product/cutters/cf572"],
    questions: ["CF360", "CF372", "CF560", "CF772"],
  },
  CF772: {
    description:
      'CF772 heavy-duty rotary brush cutter houses four AR400 blades featuring an 83" path width. The 1/4” steel deck is designed to stand up and perform in rough terrain while cutting trees, brush, unwanted weeds and grass.',
    links: ["https://online-order.baumalight.com/product/cutters/cf"],
    questions: ["CF360", "CF372", "CF560", "CF572"],
  },
  "Boom Mower Skidsteers": {
    description:
      "The Rotary Brush Cutter is a heavy-duty rotary brush mower designed to efficiently destroy dense vegetation. Capable of taking on the stringy, dense undergrowth and has a heavy duty solid frame which is meant for rough terrain.",
    links: ["https://online-order.baumalight.com/product/cutters/cf360"],
    questions: ["Flail Mower Skidsteer", "Rotary Mowers Skidsteer"],
  },
  "Flail Mower Skidsteer": {
    description:
      "Baumalight’s Boom Mower for Skidsteer allows you to easily maintain roadside and fence line grass and brush. It is designed to work with skidsteers with a minimum carrier weight of 4,500 lbs.",
    links: [
      "https://online-order.baumalight.com/product/boom-mower-skidsteer/swa540",
    ],
    questions: ["SWA540", "SWA550", "SWA560", "SWF560", "SWF580"],
  },
  "Rotary Mowers Skidsteer": {
    description:
      "Baumalight’s SWA750 Boom Mower is a convenient skidsteer attachment that makes mowing ditches, roadsides and fence lines easier than ever. Unlike our other ditch mower models, the SWA750 uses rotary cutting blades instead of our flail teeth.",
    links: [
      "https://online-order.baumalight.com/product/boom-mower-skidsteer/swa750",
    ],
    questions: ["SWA750"],
  },
  SWA750: {
    description:
      "Baumalight’s SWA750 Boom Mower is a convenient skidsteer attachment that makes mowing ditches, roadsides and fence lines easier than ever. Unlike our other ditch mower models, the SWA750 uses rotary cutting blades instead of our flail teeth.",
    links: [
      "https://online-order.baumalight.com/product/boom-mower-skidsteer/swa750",
    ],
  },
  SWA540: {
    description:
      "Baumalight’s SWA540 Boom Mower for Skidsteer allows you to easily maintain roadside and fence line grass and brush. The SWA540 is designed to work with skidsteers with a minimum carrier weight of 4,500 lbs.",
    links: [
      "https://online-order.baumalight.com/product/boom-mower-skidsteer/swa540",
    ],
    questions: ["SWA550", "SWA560", "SWF560", "SWF580"],
  },
  SWA550: {
    description:
      "Baumalight’s SWA550 Boom Mower for Skidsteer allows you to easily access hard to reach grass and brush. With a 7 foot reach, the curved single arm boom is ideal for maintaining your ditches, roadside and fence lines.",
    links: [
      "https://online-order.baumalight.com/product/boom-mower-skidsteer/swa550",
    ],
    questions: ["SWA540", "SWA560", "SWF560", "SWF580"],
  },
  SWA560: {
    description:
      "Baumalight’s SWA560 Boom Mower is a convenient skidsteer attachment that makes mowing ditches, roadsides and fence lines easier than ever. The SWA560 ditch mower is designed to work with skidsteers with a minimum carrier weight of 5,500 lbs.",
    links: [
      "https://online-order.baumalight.com/product/boom-mower-skidsteer/swa560",
    ],
    questions: ["SWA540", "SWA550", "SWF560", "SWF580"],
  },
  SWF560: {
    description:
      "Baumalight’s SWF560 Boom Mower for Skidsteers is a must have attachment for mowing grass and long brush in your ditches, roadsides and fence lines. The SWF560 ditch mower has a 10 ft.",
    links: [
      "https://online-order.baumalight.com/product/boom-mower-skidsteer/swf560",
    ],
    questions: ["SWA540", "SWA550", "SWA560", "SWF580"],
  },
  SWF580: {
    description:
      "Baumalight’s SWF580 Boom Mower is a heavy duty ditch mower for Skidsteers. You can now safely mow the grass and long brush in your ditches, roadsides and fence lines.",
    links: [
      "https://online-order.baumalight.com/product/boom-mower-skidsteer/swf580",
    ],
    questions: ["SWA540", "SWA550", "SWA560", "SWF560"],
  },
  "Screw Splitters Skidsteers": {
    description:
      "Skidsteer models have a Stump Planer tool that is designed to mount using a Skidsteer plate. The RSS model operates at a low RPM so that chips are contained during the operation with very little mess to clean up..",
    links: [
      "https://online-order.baumalight.com/product/stump-planer/planer-rss380",
    ],
    questions: ["RSS380", "RSS580", "RSS780"],
  },
};

const messageContainer = document.getElementById("messages");

function addMessage(message, isUserMessage) {
  const messageContainer = document.getElementById("messages");
  const messageElement = document.createElement("div");
  messageElement.className = isUserMessage
    ? "message-container user-message"
    : "message-container bot-message";
  messageElement.innerHTML = `
        <div class="message ${
          isUserMessage ? "sender" : "receiver"
        }">${message}</div>
        <div class="message-timestamp ${
          isUserMessage ? "timestamp-right" : "timestamp-left"
        }">${getCurrentTime()}</div>
    `;
  messageContainer.appendChild(messageElement);
  messageContainer.scrollTop = messageContainer.scrollHeight;
}

// Keep your existing dropdownResponses object
function handleDropdownItemClick(event) {
  const dropdownItem = event.currentTarget;
  const dropdown = dropdownItem.closest(".dropdown-content");

  let itemText = Array.from(dropdownItem.childNodes)
    .filter((node) => node.nodeType === Node.TEXT_NODE)
    .map((node) => node.textContent.trim())
    .join("");

  itemText = itemText.trim();

  if (dropdown) {
    dropdown.classList.remove("active");
    dropdown.style.display = "none";
  }

  addDropdownMessage(itemText, "sender1", messageContainer);

  displayStaticResponse(itemText, messageContainer);
}

function addDropdownMessage(content, type, messageContainer) {
  const messageDiv = document.createElement("div");
  messageDiv.className = `message-dropdown ${type}`;
  messageDiv.textContent = content;
  const timestampElement = document.createElement("div");
  timestampElement.className = "message-timestamp timestamp-right";
  timestampElement.textContent = getCurrentTime();
  messageContainer.appendChild(messageDiv);
  messageContainer.appendChild(timestampElement);
  messageContainer.scrollTop = messageContainer.scrollHeight;
}

function handleQuestionClick(event) {
  const button = event.target;
  if (button.classList.contains("clickable-question1")) {
    const question =
      button.getAttribute("data-question1") || button.textContent;

    // Add the clicked question as a sender1 message
    addMessageAsSender1(question, messageContainer);

    // Display the static response for this question
    displayStaticResponse(question, messageContainer);
  }
}

function addMessageAsSender1(content, messageContainer) {
  const messageDiv = document.createElement("div");
  messageDiv.className = "message-dropdown sender1";
  messageDiv.textContent = content;
  const timestampElement = document.createElement("div");
  timestampElement.className = "message-timestamp timestamp-right";
  timestampElement.textContent = getCurrentTime();
  messageContainer.appendChild(messageDiv);
  messageContainer.appendChild(timestampElement);
  messageContainer.scrollTop = messageContainer.scrollHeight;
}

function displayStaticResponse(itemText, messageContainer) {
  const response = dropdownResponses[itemText];

  if (response) {
    // Create a container for the new response
    const responseContainer = document.createElement("div");

    // Add description
    if (response.description) {
      const descDiv = document.createElement("div");
      descDiv.className = "message-daq receiver1";
      descDiv.innerHTML = `<p>${response.description}</p>`;
      responseContainer.appendChild(descDiv);
    }

    // Add links
    if (response.links && response.links.length > 0) {
      const linksDiv = document.createElement("div");
      linksDiv.className = "message-daq receiver1";
      let linksHtml = "<strong>Read more about the product</strong><ul>";
      response.links.forEach((link) => {
        // Handle special cases for display text
        let displayText = itemText;
        if (itemText === "Upcoming New Product Release") {
          displayText = "Barrier Mower";
        } else if (itemText === "Discounts and Offers") {
          displayText = "Factory Discounts";
        }

        linksHtml += `<li><a href="${link}" target="_blank">${displayText}</a><img src="./static/images/external.png" alt="Baumalight Mascot" class="link-icon-sm"></li>`;
      });
      linksHtml += "</ul>";
      linksDiv.innerHTML = linksHtml;
      responseContainer.appendChild(linksDiv);
    }

    // Add questions.
    if (response.questions && response.questions.length > 0) {
      const questionsDiv = document.createElement("div");
      questionsDiv.className = "message-daq receiver1";
      let questionsHTML = "<strong>Below are the related Models</strong><ul>";
      questionsDiv.innerHTML = questionsHTML;

      response.questions.forEach((question) => {
        const button = document.createElement("button");
        button.className = "clickable-question1 statement-container1";
        button.setAttribute("data-question1", question);

        // Remove suffixes from display text while keeping the full value in data attribute
        let displayText = question
          .replace(/ Excvator$/, "")
          .replace(/ Tractor$/, "")
          .replace(/ Skidsteer$/, "")
          .replace(/ Skidsteers$/, "");

        button.textContent = displayText;
        questionsDiv.appendChild(button);
      });

      responseContainer.appendChild(questionsDiv);
    }

    // Append the new response container to the message container
    messageContainer.appendChild(responseContainer);

    // Create a container for timestamp and feedback icons
    const timestampContainer = document.createElement("div");
    timestampContainer.className = "timestamp-feedback-container";

    // Add timestamp
    const timestampElement = document.createElement("div");
    timestampElement.className = "message-timestamp timestamp-left";
    timestampElement.textContent = getCurrentTime();

    // Add feedback icons
    const feedbackIcons = document.createElement("div");
    feedbackIcons.className = "feedback-icons";
    feedbackIcons.innerHTML = `
            <i class="fa-regular fa-thumbs-up thumb-icon" id="thumbs-up"></i>
            <i class="fa-regular fa-thumbs-down thumb-icon" id="thumbs-down"></i>
        `;

    // Append timestamp and feedback icons to their container
    timestampContainer.appendChild(timestampElement);
    timestampContainer.appendChild(feedbackIcons);

    // Append the container to the message container
    messageContainer.appendChild(timestampContainer);

    // Scroll to the bottom of the chat
    messageContainer.scrollTop = messageContainer.scrollHeight;
  } else {
    // If no response found, add a default message
    const defaultMessageDiv = document.createElement("div");
    defaultMessageDiv.className = "message-daq receiver1";
    defaultMessageDiv.innerHTML = `<p>I couldn't find any specific product in your request.</p>`;
    // Create a container for timestamp and feedback icons
    const timestampContainer = document.createElement("div");
    timestampContainer.className = "timestamp-feedback-container";

    // Add timestamp
    const timestampElement = document.createElement("div");
    timestampElement.className = "message-timestamp timestamp-left";
    timestampElement.textContent = getCurrentTime();

    // Add feedback icons
    const feedbackIcons = document.createElement("div");
    feedbackIcons.className = "feedback-icons";
    feedbackIcons.innerHTML = `
            <i class="fa-regular fa-thumbs-up thumb-icon" id="thumbs-up"></i>
            <i class="fa-regular fa-thumbs-down thumb-icon" id="thumbs-down"></i>
        `;

    // Append timestamp and feedback icons to their container
    timestampContainer.appendChild(timestampElement);
    timestampContainer.appendChild(feedbackIcons);

    // Append the container to the message container
    messageContainer.appendChild(defaultMessageDiv);
    messageContainer.appendChild(timestampContainer);
    messageContainer.scrollTop = messageContainer.scrollHeight;
  }
  messageContainer.scrollTop = messageContainer.scrollHeight;
}

// Modified DOMContentLoaded event listener
document.addEventListener("DOMContentLoaded", () => {
  showDropdown("whatsNewDropdown");

  // Add click listeners to dropdown items
  const dropdownItems = document.querySelectorAll(".dropdown-item");
  dropdownItems.forEach((item) => {
    item.addEventListener("click", handleDropdownItemClick);
  });

  // Add click listener for clickable questions in the chat
  messageContainer.addEventListener("click", handleQuestionClick);

  // Chat input and send button functionality remains the same
  const messageInput = document.getElementById("message-input");
  const sendButton = document.getElementById("send-button");

  sendButton.addEventListener("click", () => {
    const message = messageInput.value.trim();
    if (message) {
      addMessage(message, true);
      messageInput.value = "";
      // Your existing chat handling logic here
    }
  });

  messageInput.addEventListener("keypress", (event) => {
    if (event.key === "Enter") {
      sendButton.click();
    }
  });
});

// Function to remove all feedback icons
function removeFeedbackIcons() {
  const feedbackIcons = document.querySelectorAll(".feedback-icons");
  feedbackIcons.forEach((icons) => icons.remove());
}

// Update the click handler for feedback icons
document.addEventListener("click", function (event) {
  if (event.target.classList.contains("thumb-icon")) {
    const iconType = event.target.id;
    const feedbackContainer = event.target.closest(".feedback-icons");

    if (feedbackContainer) {
      const feedbackMessage = document.createElement("div");
      feedbackMessage.className = "message-daqr";
      feedbackMessage.textContent =
        iconType === "thumbs-up"
          ? "Thank you for your feedback!"
          : "Sorry to hear that! We value your feedback.";

      const messageContainer = document.getElementById("messages");
      messageContainer.appendChild(feedbackMessage);

      // Remove all feedback icons after clicking
      removeFeedbackIcons();

      messageContainer.scrollTop = messageContainer.scrollHeight;
    }
  }
});

function toggleDropdown(dropdownId) {
  const dropdown = document.getElementById(dropdownId);
  const allDropdowns = document.querySelectorAll(".dropdown-content");

  // Close all other dropdowns
  allDropdowns.forEach((d) => {
    if (d.id !== dropdownId) {
      d.classList.remove("active");
      d.style.display = "none";
    }
  });

  // Toggle the clicked dropdown
  if (dropdown) {
    const isCurrentlyActive = dropdown.classList.contains("active");
    dropdown.classList.toggle("active");
    dropdown.style.display = isCurrentlyActive ? "none" : "grid";

    // Toggle the chevron rotation
    const button = document.querySelector(
      `button[onclick="toggleDropdown('${dropdownId}')"]`
    );
    if (button) {
      const chevron = button.querySelector(".chevron img");
      if (chevron) {
        chevron.style.transform = isCurrentlyActive
          ? "rotate(180deg)"
          : "rotate(0deg)";
      }
    }
  }
}

// Modify the DOMContentLoaded event listener
document.addEventListener("DOMContentLoaded", () => {
  // Show the What's New dropdown initially if needed
  showDropdown("whatsNewDropdown");

  // Add click listeners to dropdown items
  const dropdownItems = document.querySelectorAll(".dropdown-item");
  dropdownItems.forEach((item) => {
    item.addEventListener("click", handleDropdownItemClick);
  });

  // Chat input and send button functionality
  const messageInput = document.getElementById("message-input");
  const sendButton = document.getElementById("send-button");

  sendButton.addEventListener("click", () => {
    const message = messageInput.value.trim();
    if (message) {
      addMessage(message, true);
      messageInput.value = "";

      // Your existing chat handling logic here
      setTimeout(() => {
        addMessage(`Response to: ${message}`, false);
      }, 1000);
    }
  });

  // Add keypress event for Enter key
  messageInput.addEventListener("keypress", (event) => {
    if (event.key === "Enter") {
      sendButton.click();
    }
  });
});

// Keep your existing showDropdown function
function showDropdown(dropdownId) {
  const dropdown = document.getElementById(dropdownId);
  if (dropdown) {
    dropdown.classList.add("active");
    dropdown.style.display = "grid";
  }
}

// Handle send button click
document.getElementById("send-button").addEventListener("click", () => {
  const messageInput = document.getElementById("message-input");
  const message = messageInput.value.trim();

  if (message) {
    addMessage(message, true);
    messageInput.value = "";

    // Simulate bot response (replace with your actual bot response logic)
    setTimeout(() => {
      addMessage(`Response to: ${message}`, false);
    }, 1000);
  }
});

// Function to get current time
function getCurrentTime() {
  const now = new Date();
  let hours = now.getHours();
  let minutes = now.getMinutes();
  const ampm = hours >= 12 ? "PM" : "AM";

  // Convert to 12-hour format
  hours = hours % 12;
  hours = hours ? hours : 12; // handle midnight (0 hours)

  // Add leading zero to minutes if needed
  minutes = minutes < 10 ? "0" + minutes : minutes;

  return `${hours}:${minutes} ${ampm}`;
}

// CSS to style message alignment and timestamp positioning
const style = document.createElement("style");
style.textContent = `
    .message-wrapper {
        display: flex;
        flex-direction: column;
        max-width: 70%;
    }
    .sender-wrapper {
        align-items: flex-end;
        margin-left: auto;
    }
    .response-wrapper {
        align-items: flex-start;
    }
    .message-timestamp {
        font-size: 0.75rem;
        color: #666;
        margin-top: 4px;
    }
    .timestamp-right {
        margin-right: 15px;
        text-align: end;
    }
    .timestamp-left {
        margin-left: 20px;
        text-align: start;
    }
    .message.sender {
        border-radius: 10px;
        padding: 8px 12px;
        margin-bottom: 2px;
    }
`;
document.head.appendChild(style);
