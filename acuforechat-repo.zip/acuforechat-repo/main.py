import os
import openai
import pickle
import numpy as np
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Optional
from openai.embeddings_utils import get_embedding
import logging
from sklearn.metrics.pairwise import cosine_similarity
from dotenv import load_dotenv
import tiktoken
import json
import re

# Load environment variables
load_dotenv()

# Load model comparisons data
with open("product_files/comparisons.json", "r") as f:
    model_comparisons = json.load(f)

# Load dealers data
with open("product_files/dealers.json", "r") as f:
    dealers_data = json.load(f)

# Configure logging
logger = logging.getLogger(__name__)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

# Initialize tokenizer
GPT_MODEL = "gpt-4o-mini"
EMBEDDING_MODEL = "text-embedding-ada-002"
encoding = tiktoken.encoding_for_model(GPT_MODEL)

# Global token usage tracking
token_usage = {
    "prompt_tokens": 0,
    "completion_tokens": 0,
    "total_tokens": 0,
    "embedding_tokens": 0
}

def count_tokens(text: str) -> int:
    """Count the number of tokens in a text string."""
    return len(encoding.encode(text))

from collections import defaultdict

chat_history = defaultdict(list)  # {ip_address: [summary1, summary2, ...]}

# === CONFIG ===
openai.api_key = os.getenv('OPENAI_API_KEY')
VECTOR_META_PATH = "metadata.pkl"
VECTOR_EMBEDDINGS_PATH = "vector_embeddings.pkl"
EMBEDDING_MODEL = "text-embedding-ada-002"  # OpenAI model for embeddings
MAX_TOKENS = 500
# === FASTAPI SETUP ===
app = FastAPI()

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Setup templates
templates = Jinja2Templates(directory="templates")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"]
)

# === MODELS ===
class ChatRequest(BaseModel):
    prompt: str
    max_results: Optional[int] = 3
    include_sources: Optional[bool] = True

class SearchResult:
    def __init__(self, content, source=None):
        self.content = content
        self.source = source

def get_embedding(text: str, engine: str = EMBEDDING_MODEL) -> list:
    global token_usage
    text = text.replace("\n", " ")  # Clean input
    # Count embedding tokens
    num_tokens = count_tokens(text)
    token_usage["embedding_tokens"] += num_tokens
    logger.info(f"Embedding Request - Text: {text[:100]}... ({num_tokens} tokens)")
    
    response = openai.Embedding.create(
        input=[text],
        model=engine
    )
    return response["data"][0]["embedding"], num_tokens

# === UTILITIES ===
def chunk_text(text, max_tokens=500, overlap=100):
    words = text.split()
    chunks = []
    start = 0
    while start < len(words):
        end = min(start + max_tokens, len(words))
        chunk = " ".join(words[start:end])
        chunks.append(chunk)
        start += max_tokens - overlap
    return chunks


def read_product_files(directory="product_files"):
    files = []
    if not os.path.exists(directory):
        return []
    for filename in os.listdir(directory):
        if filename.endswith(('.txt', '.md', '.json')):
            try:
                with open(os.path.join(directory, filename), "r", encoding="utf-8") as f:
                    content = f.read()
                    files.append(SearchResult(content=content, source=filename))
            except Exception:
                continue
    return files
def build_vector_index():
    documents = []
    metadata = []
    chunk_embeddings = []

    for filename in os.listdir("product_files"):
        if filename.endswith((".txt", ".md", ".json")):
            path = os.path.join("product_files", filename)
            with open(path, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if not content:
                    continue

                # Split into chunks
                chunks = chunk_text(content, max_tokens=500, overlap=100)
                for chunk in chunks:
                    embedding, tokens = get_embedding(chunk, engine=EMBEDDING_MODEL)
                    logger.info(f"Chunk Embedding - Source: {filename}, Tokens: {tokens}")
                    chunk_embeddings.append({
                        "embedding": embedding,
                        "chunk": chunk,
                        "source": filename
                    })

    with open("chunk_embeddings.pkl", "wb") as f:
        pickle.dump(chunk_embeddings, f)


def get_relevant_chunks(query, k=3, max_tokens=MAX_TOKENS):
    # sourcery skip: inline-immediately-returned-variable
    query_embedding, embedding_tokens = get_embedding(query, engine=EMBEDDING_MODEL)
    token_usage["embedding_tokens"] += embedding_tokens

    with open("chunk_embeddings.pkl", "rb") as f:
        all_chunks = pickle.load(f)

    similarities = []
    for chunk_info in all_chunks:
        similarity = cosine_similarity([query_embedding], [chunk_info["embedding"]])[0][0]
        similarities.append((similarity, chunk_info))

    similarities.sort(key=lambda x: x[0], reverse=True)

    selected_chunks = []
    total_tokens = 0
    for similarity, chunk_info in similarities:
        chunk_tokens = len(chunk_info["chunk"].split())
        if total_tokens + chunk_tokens <= max_tokens:
            selected_chunks.append(chunk_info)
            total_tokens += chunk_tokens
        else:
            break

    results = [
        SearchResult(content=chunk["chunk"], source=chunk["source"])
        for chunk in selected_chunks
    ]

    return results

def summarize_message(message: str) -> str:
    try:
        prompt = f"Summarize this message in one short sentence:\n\n{message}"
        response = openai.ChatCompletion.create(
            model=GPT_MODEL,
            messages=[
                {"role": "system", "content": "You are a helpful summarizer."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,
            max_tokens=30
        )
        return response["choices"][0]["message"]["content"].strip()
    except Exception as e:
        logger.error(f"Error in summarize_message: {str(e)}")
        # Fallback to simple truncation if summarization fails
        return message[:100] + "..." if len(message) > 100 else message

# === ROUTES ===
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

from collections import defaultdict

# In-memory chat history
chat_history = defaultdict(list)

def summarize_message(text):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4o-mini", 
            messages=[
                {"role": "system", "content": "Summarize the following user message in one sentence:"},
                {"role": "user", "content": text}
            ],
            temperature=0.3,
            max_tokens=30
        )
        summary = response["choices"][0]["message"]["content"]
        return summary.strip()
    except Exception as e:
        # Fallback to basic truncation
        return text[:60].strip().replace("\n", " ") + "..." if len(text) > 60 else text

def get_model_comparison_data(query: str) -> dict:
    """Extract relevant model comparison data based on the query."""
    relevant_data = {
        "models": {},
        "series_info": {}
    }
    
    # Convert query to lowercase for case-insensitive matching
    query_lower = query.lower()
    
    # Check for specific series mentions
    series_keywords = {
        "tx": "TX Models",
        "kr": "KR Models",
        "qc": "QC Models"
    }
    
    for keyword, series in series_keywords.items():
        if keyword in query_lower:
            if series in model_comparisons:
                relevant_data["models"].update(model_comparisons[series])
                
    # If no specific series mentioned, include all for comparison queries
    if "compar" in query_lower or "vs" in query_lower or "difference" in query_lower:
        for series in series_keywords.values():
            if series in model_comparisons:
                relevant_data["models"].update(model_comparisons[series])
    
    return relevant_data

def extract_postal_code(text: str) -> Optional[str]:
    """Extract postal/zip code from text using regex patterns."""
    # Canadian postal code pattern (A1A 1A1)
    ca_pattern = r'[A-Za-z]\d[A-Za-z]\s?\d[A-Za-z]\d'
    # US ZIP code pattern (12345 or 12345-6789)
    us_pattern = r'\b\d{5}(?:-\d{4})?\b'
    # Indian PIN code pattern (6 digits)
    in_pattern = r'\b\d{6}\b'
    
    # Try Canadian postal code first
    ca_match = re.search(ca_pattern, text)
    if ca_match:
        return ca_match.group().upper().replace(" ", "")
    
    # Try US ZIP code
    us_match = re.search(us_pattern, text)
    if us_match:
        return us_match.group()
    
    # Try Indian PIN code
    in_match = re.search(in_pattern, text)
    if in_match:
        return in_match.group()
    
    return None

def calculate_postal_similarity(code1: str, code2: str) -> float:
    """Calculate similarity between two postal codes."""
    # Convert both codes to uppercase and remove spaces
    code1 = code1.upper().replace(" ", "")
    code2 = code2.upper().replace(" ", "")
    
    # If either code is empty, return 0
    if not code1 or not code2:
        return 0
    
    # If codes are identical, return 1
    if code1 == code2:
        return 1
    
    # For Canadian postal codes (e.g., "M5V2T6")
    if len(code1) == 6 and len(code2) == 6 and not code1.isdigit() and not code2.isdigit():
        # Give more weight to first characters as they indicate geographical region
        weights = [0.4, 0.2, 0.1, 0.1, 0.1, 0.1]
        similarity = sum(w for i, w in enumerate(weights) if i < len(code1) and i < len(code2) and code1[i] == code2[i])
        return similarity
    
    # For numeric postal codes (US ZIP or Indian PIN)
    if code1.isdigit() and code2.isdigit():
        # Calculate similarity based on common prefix and numerical proximity
        common_prefix = 0
        for c1, c2 in zip(code1, code2):
            if c1 == c2:
                common_prefix += 1
            else:
                break
        
        # Add similarity based on numerical proximity for the first 3 digits
        prefix1 = int(code1[:3]) if len(code1) >= 3 else int(code1)
        prefix2 = int(code2[:3]) if len(code2) >= 3 else int(code2)
        numerical_similarity = 1 - min(abs(prefix1 - prefix2) / 1000, 1)
        
        return (common_prefix / max(len(code1), len(code2)) + numerical_similarity) / 2
    
    # If mixing different formats, return low similarity
    return 0.1

def find_nearest_dealers(postal_code: str, num_dealers: int = 3) -> list:
    """Find the nearest dealers based on postal code similarity."""
    if not postal_code:
        return []
    
    # Calculate similarity scores for all dealers
    dealer_scores = []
    for dealer in dealers_data["dealers"]:
        similarity = calculate_postal_similarity(postal_code, dealer["location"])
        dealer_scores.append((similarity, dealer))
    
    # Sort by similarity score (descending) and return top N dealers
    dealer_scores.sort(reverse=True, key=lambda x: x[0])
    return [dealer for _, dealer in dealer_scores[:num_dealers]]

def is_dealer_query(text: str) -> bool:
    """Check if the query is about finding dealers."""
    dealer_keywords = [
        "dealer", "dealers", "store", "location", "nearest", "closest", "near me",
        "where can i buy", "where to buy", "shop", "purchase location", "near to me"
    ]
    text_lower = text.lower()
    
    # If it's just a postal code, don't treat it as a new dealer query
    if extract_postal_code(text) and len(text.strip()) <= 7:
        return False
        
    return any(keyword in text_lower for keyword in dealer_keywords)

@app.post("/ask")
async def ask_bot(request: Request):
    global token_usage
    try:
        body = await request.json()
        chat_request = ChatRequest(**body)
        question = chat_request.prompt.strip()
        
        # Check if this is a dealer-related query or contains a postal code
        is_dealer = is_dealer_query(question)
        postal_code = extract_postal_code(question)
        
        # Handle dealer queries
        if is_dealer or postal_code:
            if not postal_code:
                return {
                    "response": json.dumps({
                        "Description": "I can help you find the nearest dealers. Could you please provide your postal/ZIP code or PIN code?",
                        "Links": [],
                        "Questions": []
                    })
                }
            
            # Find nearest dealers
            nearest_dealers = find_nearest_dealers(postal_code)
            
            if not nearest_dealers:
                return {
                    "response": json.dumps({
                        "Description": f"I notice you're looking from PIN code {postal_code}. Currently, our dealers are located in North America. Here are all our available dealers for your reference:<br><br>" + 
                        "<br>".join([
                            f"*{dealer['company']}*<br>" +
                            f"━━━━━━━━━━━━━━━━━━━━━━<br>" +
                            f"Address: {dealer['address']}<br>" +
                            f"Phone: {dealer['phone']}<br>" +
                            f"Email: {dealer['email']}<br>"
                            for dealer in dealers_data["dealers"][:3]
                        ]),
                        "Links": [],
                        "Questions": []
                    })
                }
            
            # Format dealer information
            dealer_info = []
            for dealer in nearest_dealers:
                dealer_info.append(
                    f"*{dealer['company']}*<br>" +
                    f"━━━━━━━━━━━━━━━━━━━━━━<br>" +
                    f"Address: {dealer['address']}<br>" +
                    f"Phone: {dealer['phone']}<br>" +
                    f"Email: {dealer['email']}<br>"
                )
            
            description = f"Here are the dealers closest to {postal_code}:<br><br>" + "<br>".join(dealer_info)
            
            return {
                "response": json.dumps({
                    "Description": description,
                    "Links": [],
                    "Questions": []
                })
            }

        # If not a dealer query, continue with existing product query handling
        k = chat_request.max_results
        include_sources = chat_request.include_sources
        
        # Log user input
        logger.info(f"Processing user input: {question}")
        
        if not question:
            return {
                "response": json.dumps({
                    "Description": "Please provide a question or message.",
                    "Links": [],
                    "Questions": ["What would you like to know about our products?"]
                })
            }

        # Get model comparison data if relevant
        model_data = get_model_comparison_data(question)

        # Get relevant chunks with expanded context
        try:
            relevant_chunks = get_relevant_chunks(question, k=k+2)  # Get extra chunks for better context
        except Exception as e:
            logger.error(f"Error getting relevant chunks: {str(e)}")
            return {
                "response": json.dumps({
                    "Description": "I'm having trouble processing your request.",
                    "Links": [],
                    "Questions": ["Could you try asking your question again?"]
                })
            }
        
        if not relevant_chunks and not model_data["models"]:
            logger.warning(f"No relevant information found for query: {question}")
            return {
                "response": json.dumps({
                    "Description": "I couldn't find specific information about that. Could you please rephrase your question?",
                    "Links": [],
                    "Questions": [
                        "Would you like to know about our available generator models?",
                        "Can I help you with something specific about Baumalight equipment?"
                    ]
                })
            }

        # Build enhanced context from chunks and model data
        document_context = "\n\n".join([
            f"Context {i+1}:\nSource: {chunk.source}\n{chunk.content}"
            for i, chunk in enumerate(relevant_chunks)
        ])
        
        # Add model comparison data to context if available
        if model_data["models"]:
            document_context += "\n\nModel Comparison Data:\n" + json.dumps(model_data["models"], indent=2)

        # Create conversation messages
        messages = [
            {
                "role": "system",
                "content": (
                    "You are the official Baumalight product assistant.\n"
                    "Use _only_ the data provided below—no hallucinations, no external advice.\n"
                    "If the user asks for a field (price, lead time, KW, etc.) that is not in the data:\n"
                    "1. DO NOT create a link saying 'I don't have that information'\n"
                    "2. Instead say 'That specific information is not available' in the Description\n"
                    "3. Always provide relevant series links in the Links section\n"
                    "4. Ask relevant follow-up questions about available information\n\n"
                    "Structure your responses in exactly three sections:\n"
                    "1. Description: Provide a clear, concise overview\n"
                    "2. Links: List full URLs to relevant product pages, separated by commas\n"
                    "3. Questions: List 2-3 follow-up questions, separated by commas\n\n"
                    "Rules:\n"
                    "- Keep descriptions focused and under 150 words\n"
                    "- Always provide complete, valid URLs\n"
                    "- Format questions as complete sentences\n\n"
                    "Example format:\n"
                    "Description: Your detailed description here.\n"
                    "Links: When mentioning products, use these exact links:\n"
                    "- TX Series: https://online-order.baumalight.com/product/generators/tx-series\n"
                    "- TX Models: https://online-order.baumalight.com/product/generators/tx-models\n"
                    "- KR Series: https://online-order.baumalight.com/product/generators/kr-models\n"
                    "- QC Single Phase: https://online-order.baumalight.com/product/generators/qc-singlephase\n"
                    "- QC 120/208V 3-Phase: https://online-order.baumalight.com/product/generators/qc-120\n"
                    "- QC 120/240V 3-Phase: https://online-order.baumalight.com/product/generators/qc-3phase\n"
                    "- QC 480V 3-Phase: https://online-order.baumalight.com/product/generators/qc-volt480\n"
                    "- QC 600V 3-Phase: https://online-order.baumalight.com/product/generators/qc-volt600\n"
                    "Questions: What specific features are you looking for?, Would you like to know about installation?\n\n"
                    "- Format questions as complete sentences\n"
                    "- When comparing models, focus on key differences in specifications\n"
                    "- Include pricing and availability information when relevant\n\n"
                    "Context Information:\n" + document_context
                )
            },
            {"role": "user", "content": question}
        ]

        # Get response from OpenAI
        response = openai.ChatCompletion.create(
            model=GPT_MODEL,
            messages=messages,
            temperature=0.3,
            max_tokens=500
        )
        answer = response["choices"][0]["message"]["content"].strip()
        
        # Check for simple greetings first
        greeting_words = ["hi", "hello", "hey", "good morning", "good afternoon", "good evening"]
        is_greeting = question.lower().strip() in greeting_words
        
        if is_greeting:
            return {
                "response": json.dumps({
                    "Description": "Hi! How can I help you with Baumalight products today?",
                    "Links": [],
                    "Questions": []
                })
            }

        # Check for simple responses
        simple_responses = ["thank you", "thanks", "ok", "goodbye", "bye", "good bye"]
        is_simple_response = any(answer.lower().strip().startswith(resp) for resp in simple_responses)
        
        if is_simple_response:
            return {
                "response": json.dumps({
                    "Description": answer,
                    "Links": [],
                    "Questions": []
                })
            }

        # Parse the response into sections
        sections = {
            "Description": "",
            "Links": [],
            "Questions": []
        }
        
        current_section = None
        lines = answer.split('\n')
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # Check for section headers
            lower_line = line.lower()
            if lower_line.startswith("description:"):
                current_section = "Description"
                line = line[len("description:"):].strip()
            elif lower_line.startswith("links:"):
                current_section = "Links"
                line = line[len("links:"):].strip()
            elif lower_line.startswith("questions:"):
                current_section = "Questions"
                line = line[len("questions:"):].strip()
            
            # Add content to appropriate section
            if current_section == "Description":
                if sections["Description"]:
                    sections["Description"] += " " + line
                else:
                    sections["Description"] = line
            elif current_section == "Links":
                # Split links by comma and clean them
                if line:
                    links = [link.strip() for link in line.split(",")]
                    # Format each link as an HTML anchor tag with additional styling
                    formatted_links = []
                    for link in links:
                        if link and not link.startswith("-"):
                            # Skip any "I don't have that information" links
                            if "don't have that information" not in link.lower():
                                # Extract the last part of the URL for the display text
                                display_text = link.split("/")[-1].replace("-", " ").title()
                                formatted_link = f'<a href="{link}" target="_blank">{display_text}</a>'
                                formatted_links.append(formatted_link)
                    sections["Links"].extend(formatted_links)
            elif current_section == "Questions":
                # Split questions by comma and also by question marks followed by space
                if line:
                    # First split by commas
                    questions = [q.strip() for q in line.split(",")]
                    
                    # For each question, check if it contains multiple questions separated by question mark
                    parsed_questions = []
                    for q in questions:
                        # Split by question mark + space/whitespace, but preserve the question mark
                        sub_questions = [sq.strip() + "?" for sq in q.split("? ") if sq.strip()]
                        # Remove the extra question mark from the last question if it already had one
                        if sub_questions and sub_questions[-1].endswith("??"):
                            sub_questions[-1] = sub_questions[-1][:-1]
                        parsed_questions.extend(sub_questions)
                    
                    # Add only non-empty questions that don't start with dash
                    sections["Questions"].extend([q for q in parsed_questions if q and not q.startswith("-")])

        # Clean up sections
        sections["Description"] = sections["Description"].strip()
        
        # Remove any duplicates while preserving order
        sections["Links"] = list(dict.fromkeys(sections["Links"]))
        sections["Questions"] = list(dict.fromkeys([q.strip() for q in sections["Questions"] if q.strip()]))

        # Ensure all questions end with question mark
        sections["Questions"] = [
            q + "?" if not q.endswith("?") else q
            for q in sections["Questions"]
        ]

        # If no links are provided but information is not available, add relevant series links
        if not sections["Links"] and "not available" in sections["Description"].lower():
            sections["Links"] = [
                '<a href="https://online-order.baumalight.com/product/generators/tx-models" target="_blank">TX Models</a>',
                '<a href="https://online-order.baumalight.com/product/generators/kr-models" target="_blank">KR Models</a>',
                '<a href="https://online-order.baumalight.com/product/generators/qc-singlephase" target="_blank">QC Models</a>'
            ]

        # Add default questions if none provided
        if not sections["Questions"] and not is_simple_response:
            sections["Questions"] = [
                "Would you like to know more about specific generator models?",
                "Do you need help calculating your power requirements?",
                "Are you interested in learning about our installation services?"
            ]

        logger.info(f"Generated structured response with {len(sections['Questions'])} questions")
        
        return {
            "response": json.dumps(sections)
        }

    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        return {
            "response": json.dumps({
                "Description": "I encountered an issue processing your request.",
                "Links": [],
                "Questions": ["Could you please rephrase your question?"]
            })
        }


@app.post("/rebuild-index")
async def rebuild_index():
    try:
        build_vector_index()
        return {
            "status": "success",
            "message": "Index rebuilt"
        }
    except Exception as e:
        logger.error(f"Failed to rebuild index: {str(e)}")
        return {
            "status": "error",
            "message": str(e)
        }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="192.168.5.54", port=8000)
