This is a chatbot POC. Please run virtual environment, install requirements.txt. 
You might have to run this command when the website is running in a separate terminal "Invoke-RestMethod -Uri http://localhost:8000/rebuild-index -Method POST" 
